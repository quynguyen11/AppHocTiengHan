//
//  HamChuyenManHinh.swift
//  Korean Language
//
//  Created by Quang Tran on 8/26/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit

@available(iOS 13.0, *)
extension UIViewController{

    func quayveManhinhcuthe(_ ViewID: String){
        
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                      let secondVC = storyboard.instantiateViewController(identifier: ViewID)
//
//                      secondVC.modalPresentationStyle = .fullScreen
//                      secondVC.modalTransitionStyle = .coverVertical
//
//                      present(secondVC, animated: true, completion: nil)
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: ViewID) as! UIViewController
        newViewController.modalPresentationStyle = .fullScreen
                self.present(newViewController, animated: true, completion: nil)
        
    }
    //lost internet notification
    func Alert (Message: String){
        
        let alert = UIAlertController(title: "Alert", message: Message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
        
    }
    @objc func statusManager(_ notification: Notification) {
        updateUserInterface()
    }
    func updateUserInterface() {
        switch Network.reachability.status {
        case .unreachable:
            self.Alert(Message: "Your Device is not connected with internet")
        case .wwan:
            self.Alert(Message: "Connected")
        case .wifi:
            self.Alert(Message: "Connected")
        }

    }
    //DONE lost internet notification
    
   
    
}
