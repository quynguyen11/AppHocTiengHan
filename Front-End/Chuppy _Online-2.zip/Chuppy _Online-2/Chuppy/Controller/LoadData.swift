//
//  LoadDataa.swift
//  Korean Language
//
//  Created by Quang Tran on 8/30/20.
//  Copyright © 2020 Quang Tran. All rights reserved.

import Foundation

class LoadData{
    
    var mang:[Word]  = []
    var WishList = [Int]()
    
    func loadData(){

        var request = URLRequest(url: URL(string: "http://192.168.1.4:3000/wordKorea")!)
                
                 request.httpMethod = "POST"
                 let task = URLSession.shared.dataTask(with: request){ data, response, error in
                            
                 guard let data = data,
                       let response = response as? HTTPURLResponse,
                       error == nil else {
                          print("Can not get data")
                             return
                     }
                     
                     let dataString = String(data: data,encoding:String.Encoding.utf8)
                         print(data)
                    
                     let jsonDecoder = JSONDecoder()
                     let listWord = try? jsonDecoder.decode(ListWord.self,from:data)
                     
                    
                    self.mang = listWord!.arrWord
                    for n in 0...self.mang.count{
                        self.WishList.append(0)
                    }
                    
//                           DispatchQueue.main.async {
//                            self.myTable.reloadData()
//                       }
                     
             }
                 task.resume()
        
        //đưa dữ liệu vào Realm
        
        //print(self.mang)
        
    }
    
    
    
    
}
