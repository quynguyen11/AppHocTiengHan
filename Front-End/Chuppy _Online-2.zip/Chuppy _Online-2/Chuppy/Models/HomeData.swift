//
//  DATA.swift
//  Korean Language
//
//  Created by Quang Tran on 8/25/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation

//File này để xài cho dữ liệu cấp 1 (Home)
class Dulieu {

    //struct
    var Language: String
    var Meaning: String
    var img: String
    
    init(iLanguage: String, iMeaning:String, img: String){
        self.Language = iLanguage
        self.Meaning = iMeaning
        self.img = img
        
    }
    
}


class DataDulieu{

    var Language: [Dulieu] = [Dulieu(iLanguage: "인사", iMeaning: "Chào hỏi", img: "ChaoHoi"),
                              Dulieu(iLanguage: "일반회화", iMeaning: "Cần thiết", img: "CanThiet"),
                              Dulieu(iLanguage: "민수기", iMeaning: "Màu sắc và đếm số", img: "DemSo"),]

}

