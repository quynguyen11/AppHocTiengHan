

//Sau khi pod install, thì phải build trước, rồi mới được import RealmSwift


import Foundation
import RealmSwift
//tạo table

//đây là cơ sở dữ liệu Realm
class MClass : Object {
    //cột name, kiểu dữ liệu tuỳ biến
    
    //Primary Key
    @objc dynamic var name = UUID().uuidString
    //cột idClass, kiểu dữ liệu tuỳ biến
    @objc dynamic var Language: String = ""
    @objc dynamic var Spelling: String = ""
    @objc dynamic var Meaning: String = ""
    @objc dynamic var Media: String = ""
    @objc dynamic var Types: String = ""
    @objc dynamic var LoveList: Int = 0
    
    //đọc dữ liệu, đọc toàn bộ dữ liệu trong table (class) đó
    class func getListMClass()->[MClass]{
        // Get the default Realm
        let realm = try! Realm()    //xác nhận có thư viện hay không
        let arrClass = realm.objects(MClass.self)
        let arr = Array(arrClass)
        return arr
    }
    
}


