//
//  Word.swift
//  Korean Language
//
//  Created by Apple on 8/27/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation
import RealmSwift
import UIKit


struct ListWord:Decodable{
    var kq:Int
    var arrWord:[Word]
    
    
}

struct Word:Decodable{
    
    var _id:String
    var Language: String
    var Spelling: String
    var Meaning: String
    var Media: String
    var Types: String
    
    init(id:String, language:String, spelling:String, meaning:String, Media:String, Types: String) {
        self._id = id
        self.Language = language
        self.Spelling = spelling
        self.Meaning = meaning
        self.Media = Media
        self.Types = Types
       
    }

    
}

class MongoDB{
    
    var ipRound: String = ""

    func loadData(){
            //print(Realm.Configuration.defaultConfiguration.fileURL!)
        //bắt đầu: hàm lấy ip address
            func getWiFiAddress() -> String? {
                var address : String?

                // Get list of all interfaces on the local machine:
                var ifaddr : UnsafeMutablePointer<ifaddrs>?
                guard getifaddrs(&ifaddr) == 0 else { return nil }
                guard let firstAddr = ifaddr else { return nil }

                // For each interface ...
                for ifptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
                    let interface = ifptr.pointee

                    // Check for IPv4 or IPv6 interface:
                    let addrFamily = interface.ifa_addr.pointee.sa_family
                    //if addrFamily == UInt8(AF_INET) || addrFamily == UInt8(AF_INET6) {  // **ipv6 committed
                    if addrFamily == UInt8(AF_INET){

                        // Check interface name:
                        let name = String(cString: interface.ifa_name)
                        if  name == "en0" {

                            // Convert interface address to a human readable string:
                            var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                            getnameinfo(interface.ifa_addr, socklen_t(interface.ifa_addr.pointee.sa_len),
                                        &hostname, socklen_t(hostname.count),
                                        nil, socklen_t(0), NI_NUMERICHOST)
                            address = String(cString: hostname)
                        }
                    }
                }
                freeifaddrs(ifaddr)

                return address
            }
            
        ///Kết thúc : hàm lấy ip address
        
        
        
              //ipRound = getWiFiAddress() ?? "192.168.1.0"
        //ipRound = "http://" + ipRound + ":3000"
        ipRound = "https://nameless-sands-44118.herokuapp.com"
        //ipRound = "http://172.20.10.2:3000"
        //LƯU Ý : CHẠY 2 LẦN VỚI LẦN ĐẦU SẼ LỖI, LẦN 2 SẼ LOAD ĐƯỢC
        //lưu vào user default
        UserDefaults.standard.set(ipRound, forKey: "Key") //setObject
            
            //print(ipRound)
                var mang:[Word]  = []
                var listClass = [MClass]()
                var WishList = [Int]()
        
        //để listClass là vì đây là variable lấy dữ liệu trong Realm
        listClass = MClass.getListMClass()
        
        //var request = URLRequest(url: URL(string: "http://\(ipRound):3000/wordKorea")!)
        var request = URLRequest(url: URL(string: "\(ipRound)/wordKorea")!)
        print("URL: \(request)")
                  
                     request.httpMethod = "GET"
                     let task = URLSession.shared.dataTask(with: request){ data, response, error in

                     guard let data = data, error == nil else {
                                 return
                         }
                         let jsonDecoder = JSONDecoder()
                        print("DATA: \(data)")
                        let listWord = try? jsonDecoder.decode(ListWord.self,from:data)

                        mang = listWord!.arrWord
                        //phải trong vòng lặp này mới chạy được, ra ngoài chạy không được
                        //kết hợp đưa luôn vào realm
                        
                        //neu co update
                        if mang.count != listClass.count && listClass.count > 0{
                            //co update moi thi xoa cai cu
                            let realm = try! Realm()
                            try! realm.write {
                                let deletedNotifications = realm.objects(MClass.self)
                              realm.delete(deletedNotifications)
                            }
                            
                            //get lai du lieu sau khi xoa
                            listClass = MClass.getListMClass()
                        }
                        
                        //rong hoac update moi
                        if listClass.count <= 0 {
                         for n in 0...mang.count - 1{
                            WishList.append(0)

                            //thêm vào realm
                            //mỗi lần chạy phải khai báo lại data2
                            let data2 = MClass()
                            data2.LoveList = 0
                            data2.Language = mang[n].Language
                            data2.Spelling = mang[n].Spelling
                            data2.Meaning = mang[n].Meaning
                            data2.Media = mang[n].Media
                            data2.Types = mang[n].Types
                            
                            //thêm dữ liệu vào CSDL
                                let realm = try! Realm()
                                try! realm.write {
                                     realm.add(data2)
                             }
                            //khởi tạo PlaySound
                            }
                        }
                         print(Realm.Configuration.defaultConfiguration.fileURL!)
                 }
                    task.resume()
                //}
        }
}






