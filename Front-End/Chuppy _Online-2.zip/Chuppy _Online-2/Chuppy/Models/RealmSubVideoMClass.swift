//
//  SubVideo.swift
//  Korean Language
//
//  Created by QuangTran on 11/2/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation
import RealmSwift



class SubVideoMClass : Object {
    //cột name, kiểu dữ liệu tuỳ biến
    
    //Primary Key
    @objc dynamic var name = UUID().uuidString
    @objc dynamic var Korean: String = ""
    @objc dynamic var English: String = ""
    @objc dynamic var Time: String = ""

    
    //đọc dữ liệu, đọc toàn bộ dữ liệu trong table (class) đó
    class func getListMClass()->[SubVideoMClass]{
        // Get the default Realm
        let realm = try! Realm()    //xác nhận có thư viện hay không
        let arrClass = realm.objects(SubVideoMClass.self)
        let arr = Array(arrClass)
        return arr
    }

}
