//
//  AlertViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 10/3/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift
@available(iOS 13.0, *)
@available(iOS 13.0, *)
class AlertViewController: UIViewController {
    
    @IBAction func dismissButtonTapped(_ sender: UIButton) {
        quayveManhinhcuthe("ChuHan")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        let UIUX = UIUXViewController()
        self.view.applyGradient(colours: [UIUX.part1, UIUX.part2], locations: [UIUX.loc1,UIUX.loc2])

        //DONE UI
    
    }
    
    
    @IBAction func OkBtn(_ sender: Any) {
        
                //add full list
                let realm = try! Realm()
        
                //add data
                var listClass = [MClass]()
                listClass = MClass.getListMClass()
        
            // edit
        if listClass.count > 0{
            for n in 0...listClass.count-1{
                try! realm.write {
                    listClass[n].LoveList = 1
                    }
                }
        
        
        //add sub list class
        var SublistClass = [SubMClass]()
        SublistClass = SubMClass.getListMClass()

    // edit
        for n in 0...SublistClass.count-1{
            try! realm.write {
                SublistClass[n].LoveList = 1
            }
        }
    }
        
        quayveManhinhcuthe("ChuHan")
        
        //back
        //self.dismiss(animated: true, completion: nil)
        
        
    }
}
