//
//  AuthorViewController.swift
//  Korean Language
//
//  Created by QuangTran on 12/15/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit

@available(iOS 13.0, *)
class AuthorViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func quit(_ sender: Any) {
        quayveManhinhcuthe("HomeView")
    }


}
