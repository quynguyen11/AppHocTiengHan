import UIKit
import PDFKit
import WebKit

@available(iOS 13.0, *)
@available(iOS 13.0, *)
class LearnVocabulary: UIViewController {

    @IBOutlet weak var TitleLbl: UILabel!
    @IBOutlet weak var webView: WKWebView!
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? ""
    let UIUX = UIUXViewController()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var stringURL = UserDefaults.standard.string(forKey: "KeyPdfRead") ?? ""
        
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)
        stringURL = "\(ipRound)/upload/" + stringURL
        
        print (stringURL as Any)
        
        let url: URL! = URL(string: stringURL)
        
        webView.load(URLRequest(url: url))
        
        //load label
       if UserDefaults.standard.string(forKey: "VocaOrGram") == "voca"  {
        TitleLbl.text = "Vocabulary"
       } else {
        TitleLbl.text = "Grammarly"
       }
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
    }
    
    
    @IBAction func BackBtn(_ sender: Any) {
        quayveManhinhcuthe("VocabularyOrGramma")
    }
    
}
