//
//  ViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 8/13/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import AVFoundation
import Speech
import AVKit
import RealmSwift

@available(iOS 13.0, *)
class ListenAndRepeat: UIViewController, AVAudioRecorderDelegate {
    
    
    @IBOutlet weak var Languagelbl: UILabel!
    @IBOutlet weak var Spellinglbl: UILabel!
    @IBOutlet weak var Meaninglbl: UILabel!
    
    
    @IBOutlet weak var RecordBtn: UIButton!
    @IBOutlet weak var RecodeLblTimer: UILabel!
    @IBOutlet weak var RecodeImg: UIImageView!
    @IBOutlet weak var RecodingLbl: UIButton!
    @IBOutlet weak var StopBtn: UIButton!
    @IBOutlet weak var StopLbl: UILabel!
    @IBOutlet weak var ListenBtn: UIButton!
    @IBOutlet weak var AddListBtn: UIButton!
    
    @IBOutlet weak var NextQuestionLbl: UIButton!
    @IBOutlet weak var PreviousQuestion: UIButton!
    let speechRecognizer        = SFSpeechRecognizer(locale: Locale(identifier: "ko_KR"))
    //ko_KR, en_US, vi_VN

    var recognitionRequest      : SFSpeechAudioBufferRecognitionRequest?
    var recognitionTask         : SFSpeechRecognitionTask?
    let audioEngine             = AVAudioEngine()

    var player:AVAudioPlayer!
    var sound: String = ""
    let realm = try! Realm()
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? ""
    
    var counter = 3
    var AddList = false
    var counterStop = 4
    
    var timer : Timer?
    
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    
    var value: String = ""
    var counts: Int = 0
    var random: Int = 0
    var arrSave:[String] = []
    var arrCount = 0
    let UIUX = UIUXViewController()
    var audioFilename: URL!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        self.view.applyGradient(colours: [UIUX.part1, UIUX.part2], locations: [UIUX.loc1,UIUX.loc2])

        //DONE UI

        // Do any additional setup after loading the view.
        RecordBtn.setImage(UIImage(named: "RecordBtn"), for: .normal)
        //ẩn
        RecodingLbl.isHidden = true
        StopBtn.isHidden = true
        StopLbl.isHidden = true
        ListenBtn.isHidden = true
        RecodeImg.isHidden = true
        RecodeLblTimer.isHidden = true
        RecodingLbl.isUserInteractionEnabled = false
        //bo góc
        StopBtn.layer.cornerRadius = StopBtn.frame.size.width/20
        RecordBtn.layer.cornerRadius = RecordBtn.frame.size.width/45
        
        counts = SubMClass.getListMClass().count
        if counts > 0 {
        AddListBtn.isHidden = false
        NextQuestionLbl.isHidden = false
        PreviousQuestion.isHidden = false
        random = Int.random(in: 0..<counts)
        value = SubMClass.getListMClass()[random].Language
        GenerateQuestion()
        }else{
            AddListBtn.isHidden = true
            NextQuestionLbl.isHidden = true
            PreviousQuestion.isHidden = true
        }
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
        updateUserInterface()
       
    }
    
    
    @IBAction func NextQuestion(_ sender: Any) {
        
        counts = SubMClass.getListMClass().count
         random = Int.random(in: 0..<counts)
        value = SubMClass.getListMClass()[random].Language
        
        GenerateQuestion()
        
        //save data for previousBtn
        arrSave.append(Languagelbl.text ?? "")
        arrCount = arrSave.count
        
        
    }
    
    
    
    func GenerateQuestion(){
        
        let eventResults = realm.objects(MClass.self).filter("Language == %@", value )
        
        print("TEST LANGUAGE: ",eventResults[0].Language)
        
        
        Languagelbl.text = eventResults[0].Language
        Spellinglbl.text = eventResults[0].Spelling
        Meaninglbl.text = eventResults[0].Meaning
        sound = eventResults[0].Media
        //add button image
        if eventResults[0].LoveList == 1 {
            self.AddListBtn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
            AddList = true
            
        }else{
            self.AddListBtn.setImage(UIImage(named: "AddList2"), for: .normal)
            AddList = false
        }
    }
    
    //1. khởi chạy : ẩn nút nghe, stop
    //2.Bấm vào ghi âm, hiện thông báo timmer,
    //3. hiện đangghiamlbl và nút stop có thời gian đếm ngược
    //4. nút stop chạy hết thì nút nghe xuất hiện
    
    //ghi âm
    @IBAction func RecordbTN(_ sender: Any) {
        //Count down
        //remove img
        RecordBtn.setImage(nil, for: .normal)
        //add color for button
        //show time
        RecodeLblTimer.isHidden = false
        RecodeImg.isHidden = false
        ListenBtn.isHidden = true
        //khi đang chạy thì không được phép bấm nút
        RecordBtn.isUserInteractionEnabled = false
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
    }
 
    @IBAction func BackToMenu(_ sender: Any) {
        //stop old audio
        if self.audioEngine != nil{
            try self.audioEngine.stop()
        }


        if UserDefaults.standard.string(forKey: "Back") == "1"{
            quayveManhinhcuthe("ChuHan")
        }else{
            quayveManhinhcuthe("HomeView")

        }
    }
    
    @IBAction func RepeatBtn(_ sender: Any) {
        print("IP Play Music: " + ipRound)
        print( "IP Play Music: "+"\(ipRound)/upload/" + sound)
               
        let url:URL = URL(string: "\(ipRound)/upload/" + sound)!
        do{
            let data:Data = try Data(contentsOf: url)
            player = try AVAudioPlayer(data: data)
            player.play()
                    //player.stop()
        }catch
            {
                print("Loi phat nhac")
            }//
    }
    
    @IBAction func ListenBtn(_ sender: Any) {
        
        //stop old audio
        if self.audioEngine != nil{
            try self.audioEngine.stop()
        }
        
        let url:URL = audioFilename
        do{
            let data:Data = try Data(contentsOf: url)
            player = try AVAudioPlayer(data: data)
            player.play()
                    //player.stop()
        }catch
            {
                print("Loi phat nhac")
            }//
        
        debugPrint("Listen")
    }
    
    
    @IBAction func StopBtn(_ sender: Any) {
        
        print("Finish Recording ")
        audioRecorder.stop()
        audioRecorder = nil
        
        BackToNormal()
    }
    
    @IBAction func AddList(_ sender: Any) {
        
        if AddList == false {
            AddListBtn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
            AddList = true
        }else{
            AddListBtn.setImage(UIImage(named: "AddList2"), for: .normal)
            AddList = false
        }
        //add list to database
        let eventResults = realm.objects(MClass.self).filter("Language == %@", Languagelbl.text ?? "")
        print(eventResults)
        
        //Add love list to Realm
        if eventResults[0].LoveList == 0{
          try! realm.write {
             eventResults[0].LoveList = 1
         }
        } else {
            try! realm.write {
                eventResults[0].LoveList = 0
            }
        }
    }
    
    
    @IBAction func Previous_quest(_ sender: Any) {
        if arrCount > 2{
           value = arrSave[arrCount - 1]
            arrCount = arrCount - 1
        }else{
            value = arrSave[0]
        }
        GenerateQuestion()
    }

    
    
    @objc func updateCounter() {
        
        if counter > 0 {
            counter = counter - 1
            RecodeLblTimer.text = String(counter)
        }
        if counter <= 0 {
            //phải <= thì mới hoạt động
            RecordBtn.isHidden = true
            RecodeLblTimer.isHidden = true
            RecodeImg.isHidden = true
            RecodingLbl.isHidden = false
            StopBtn.isHidden = false
            StopLbl.isHidden = false
            debugPrint("End")
            
            print("Recording ")
            startRecording()
            
            timer?.invalidate()
            timer = nil
            //countdown stop
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(CountStop), userInfo: nil, repeats: true)
            
        }
    }
    
    @objc func CountStop() {
        
        if counterStop > 0 {
            counterStop = counterStop - 1
            StopLbl.text = String(counterStop)
            //recording
            
            
        }
        if counterStop <= 0 {
            //finish recording
            ListenBtn.isHidden = true
            
            //hiện nút Ghi âm ra lại
            BackToNormal()
            
            print("Finish Recording ")
            audioRecorder.stop()
            audioRecorder = nil
            
        }
    }
    
    func startRecording() {
        audioFilename = getDocumentsDirectory().appendingPathComponent("recording.m4a")
        
        print("Dict: \(audioFilename)")

        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder.delegate = self
            audioRecorder.record()

            //recordButton.setTitle("Tap to Stop", for: .normal)
        } catch {
            print("Something Wrong")
        }
    }
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    func BackToNormal(){
        timer?.invalidate()
        timer = nil
        RecordBtn.isHidden = false
        RecordBtn.setImage(UIImage(named: "RecordBtn"), for: .normal)
        RecodingLbl.isHidden = true
        StopBtn.isHidden = true
        StopLbl.isHidden = true
        ListenBtn.isHidden = false
        RecodeImg.isHidden = true
        RecodeLblTimer.isHidden = true
        RecordBtn.isUserInteractionEnabled = true
        
        counter = 3 //waiting
        counterStop = 4 //recording
        RecodeLblTimer.text = String("3") //waiting
        StopLbl.text = String("4")  //recording
    }
    
    
}


