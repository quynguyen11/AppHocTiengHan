//
//  SubVideoTableViewCell.swift
//  Korean Language
//
//  Created by QuangTran on 11/2/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit



class SubVideoTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var Korean: UILabel!
    @IBOutlet weak var English: UILabel!
    //Bấm chọn Hidden cái Button trong storyboard
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
     
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
