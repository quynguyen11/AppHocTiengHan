//
//  VideoLearnKorean.swift
//  Korean Language
//
//  Created by QuangTran on 11/1/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation
import AVKit
import AVFoundation
import MediaPlayer
import RealmSwift
import Localize_Swift

@available(iOS 13.0, *)
class VideoLearnKorea: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    var ipRound: String = ""
    let realm = try! Realm()
    var player: AVPlayer!
    var playerLayer: AVPlayerLayer!
    var timer : Timer?
    var isVideoPlaying = false
    var i = 0
    var PlaySound:[Int] = []     // highlight
    var off = 0
    var flag = 0
    var tag = UserDefaults.standard.integer(forKey: "tag")  //get video position
    var VideoFileName: String = UserDefaults.standard.string(forKey: "VideoTitle") ?? ""
    var mang = [SubVideoMClass]()
    let UIUX = UIUXViewController()
    var SubVideoURL: String = ""
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var TimeSlider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)
        self.myTable.backgroundColor = UIUXViewController().UIBackGround
        //DONE UI
        
        myTable.delegate = self
        myTable.dataSource = self
        
        self.addData()
        
        SubVideoURL = UserDefaults.standard.string(forKey: "Key")! + "/upload/" + UserDefaults.standard.string(forKey: "SubVideoURL")!
        
        print("SubVideoURL: \(SubVideoURL)")
        


       PlayVideo()

        // Do any additional setup after loading the view.
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
    }
    
    func addData(){
        
        //lấy data từ internet về
        
        ipRound = UserDefaults.standard.string(forKey: "Key") ?? ""
 
        var request = URLRequest(url: URL(string: "\(ipRound)/videoKorean")!)
        print("URL: \(request)")

                     request.httpMethod = "GET"
                     let task = URLSession.shared.dataTask(with: request){ data, response, error in

                     guard let data = data,
                           error == nil else {
                                 return
                         }
                         let jsonDecoder = JSONDecoder()
                        //print("DATA Sub Video: \(data)")
                        let listWord = try? jsonDecoder.decode(SubVideoListWord.self,from:data)
                        
                        //print("LLLLL: \(listWord!.DSVideo[self.tag].DSLyric)")

                        DispatchQueue.main.sync {
                            
                            try! self.realm.write {
                                let deletedNotifications = self.realm.objects(SubVideoMClass.self)
                                self.realm.delete(deletedNotifications)
                            }
                            //self.tag : get video position
                            if listWord!.DSVideo[self.tag].DSLyric.count > 0{
                            for n in 0...listWord!.DSVideo[self.tag].DSLyric.count - 1{
                                self.PlaySound.append(0)

                               //thêm vào realm
                               //mỗi lần chạy phải khai báo lại data2
                               let data2 = SubVideoMClass()
                                data2.English = listWord!.DSVideo[self.tag].DSLyric[n].English
                                data2.Korean = listWord!.DSVideo[self.tag].DSLyric[n].Korean
                                data2.Time = listWord!.DSVideo[self.tag].DSLyric[n].Time
                               
                               //thêm dữ liệu vào CSDL
                                try! self.realm.write {
                                    self.realm.add(data2)
                                }
                               //khởi tạo PlaySound
                               }
                            }
                            self.mang = SubVideoMClass.getListMClass()
                            
                            
                            self.myTable.reloadData()
                        }

                 }
                    task.resume()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mang.count
        //return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! SubVideoTableViewCell

        cell.Korean.text = self.mang[indexPath.row].Korean
        cell.English.text = self.mang[indexPath.row].English

        //Thay đổi hình ảnh nút
        if self.PlaySound.count > 0 {
        if self.PlaySound[indexPath.row] == 1 {
                //phát
            cell.Korean.alpha = 1
            cell.English.alpha = 1

            self.myTable.scrollToRow(at: indexPath, at: .top, animated: true)
            
            }else {
                cell.Korean.alpha = 0.2
                cell.English.alpha = 0.2
            }
        }
        
        return cell 
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100;//Choose your custom row height
    }
    
        
    func PlayVideo(){

        if let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            let imgText: String = "VideoFile/" + VideoFileName + ".mp4"
            let fileURL = documentsUrl.appendingPathComponent(imgText)

        player = AVPlayer(url: fileURL)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer.videoGravity = .resizeAspect
        //playerLayer.videoGravity = .resize
        player.currentItem?.addObserver(self, forKeyPath: "duration", options: [.new, .initial], context: nil)
        
        addTimeObserver()   //đưa thời gian vào
        
        videoView.layer.addSublayer(playerLayer)
        }
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer.frame = videoView.bounds
    }
    
    func addTimeObserver(){
        //cứ mỗi 0.5 giây là hàm này lại nhảy, liên tục đến khi hết video
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        let mainQueue = DispatchQueue.main
        _ = player.addPeriodicTimeObserver(forInterval: interval, queue: mainQueue, using: { [weak self] time in
            guard let currentItem = self?.player.currentItem else{return}
            self?.TimeSlider.maximumValue = Float(currentItem.duration.seconds)
            self?.TimeSlider.minimumValue = 0
            self?.TimeSlider.value = Float(currentItem.currentTime().seconds)
            //print("Pressing")
            self?.currentTimeLabel.text = self?.getTimeString(from: currentItem.currentTime())
            //add time (sub) here
            let SubTime = self?.getTimeString(from: currentItem.currentTime())
            print("SubTime: \(String(describing: SubTime))")
            var n = 0
            //print("nnn: \(self!.flag)")
            //chỉnh subtitle
            while n < (self?.mang.count)!{

                         //tìm thấy sub để hiển thị
                if SubTime == self?.mang[n].Time && self?.mang[n].Korean != nil{
                             //ra lệnh cho cell chuyển sub mong muốn
                             self?.PlaySound[n] = 1  //đây là vị trí sub. Ra lệnh bật sub lên
                             
                             //tắt sub cũ
                             if n != self!.off{
                                 self?.PlaySound[self!.off] = 0
                             }
                             self?.off = n   //đây là flag

                             break   //thoát khỏi while
                         }

                n = n + 1
            }
            self?.myTable.reloadData()
        })
    }
    
    
    @IBAction func BackBtn(_ sender: Any) {
        player.pause()
        quayveManhinhcuthe("HomeView")
    }
    
    @IBAction func playPressed(_ sender: Any) {
        
       
        if isVideoPlaying {
            player.pause()
            (sender as AnyObject).setTitle("Play", for: .normal)
            isVideoPlaying = false
        }else{
            player.play()
            (sender as AnyObject).setTitle("Pause", for: .normal)
            isVideoPlaying = true
        }
        
    }
    
    @IBAction func forwardPressed(_ sender: Any) {
        guard let duration  = player.currentItem?.duration else{
                return
            }
            let playerCurrentTime = CMTimeGetSeconds(player.currentTime())
        let newTime = playerCurrentTime + 5

            if newTime < CMTimeGetSeconds(duration) {

                let time2: CMTime = CMTimeMake(value: Int64(newTime * 1000 as Float64), timescale: 1000)
                player.seek(to: time2)
            }
    }
    
    @IBAction func backwardPressed(_ sender: Any) {
       
        let playerCurrentTime = CMTimeGetSeconds(player.currentTime())
            var newTime = playerCurrentTime - 5

            if newTime < 0 {
                newTime = 0
            }
        let time2: CMTime = CMTimeMake(value: Int64(newTime * 1000 as Float64), timescale: 1000)
            player.seek(to: time2)
    }
    

    @IBAction func SliderValueChange(_ sender: UISlider) {
        //thanh kéo thời gian
        player.seek(to: CMTimeMake(value: Int64(sender.value*1000), timescale: 1000))
        
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "duration", let duration = player.currentItem?.duration.seconds, duration > 0.0 {
            self.durationLabel.text = getTimeString(from: player.currentItem!.duration)
        }
        
    }
    
    func getTimeString(from time: CMTime) -> String{
        let totalSeconds = CMTimeGetSeconds(time)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        if hours > 0 {
            return String(format: "%i:%02i:%02i", arguments: [hours, minutes, seconds])
        }else{
            return String(format: "%i:%02i", arguments: [minutes, seconds])
        }
    }
    
}
