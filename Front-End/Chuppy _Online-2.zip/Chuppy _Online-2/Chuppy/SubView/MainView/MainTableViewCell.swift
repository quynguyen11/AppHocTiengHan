//
//  MainTableViewCell.swift
//  Korean Language
//
//  Created by Quang Tran on 8/26/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit

protocol YourCellDelegate : class {
    func didPressButton(_ tag: Int)
    func PlaydidPressButton(_ tag: Int)
    
}
class MainTableViewCell: UITableViewCell {

    @IBOutlet weak var CellUI: UIView!
    @IBOutlet weak var Language: UILabel!
    @IBOutlet weak var Spelling: UILabel!
    @IBOutlet weak var Meaning: UILabel!
    @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var PlayBtn: UIButton!
    
    var cellDelegate: YourCellDelegate?
    var PlaycellDelegate: YourCellDelegate?
    // connect the button from your cell with this method
    @IBAction func buttonPressed(_ sender: UIButton) {
        cellDelegate?.didPressButton(sender.tag)
    }
    @IBAction func PlayBtnPress(_ sender: UIButton) {
        PlaycellDelegate?.PlaydidPressButton(sender.tag)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
