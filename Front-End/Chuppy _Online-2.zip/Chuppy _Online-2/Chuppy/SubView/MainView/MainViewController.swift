//
//  MainViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 8/26/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift
import AVFoundation

@available(iOS 13.0, *)
class MainViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, YourCellDelegate{
    
    func PlaydidPressButton(_ tag: Int) {
        
        //chưa có thì tạo ra
        if PlaySound.count <= 0 {
        var i = 0
          while i < self.listClass.count{
            self.PlaySound.append(0)
              i = i + 1
          }
          
            //print("PS\(self.PlaySound)")
        }
        
        //Phát âm thanh
        //print("IP Play Music: " + ipRound)
        print( "IP Play Music: "+"\(ipRound)/upload/" +  self.listClass[tag].Media)
        print(listClass[tag].Media)
        let url:URL = URL(string: "\(ipRound)/upload/" + self.listClass[tag].Media) ?? URL(string: "")!
         do{
             let data:Data = try Data(contentsOf: url)
             player = try AVAudioPlayer(data: data)
            player.play()
             //player.stop()
        }catch
        {
            print("Loi phat nhac")
        }
        
        //hiện hình nút
         print("I have pressed a play button (MainView) with a tag: \(tag)")
        PlaySound[tag] = 1
         self.myTable.reloadData()
        // sau khi đã đọc xong, thì chuyển lại như cũ
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            // Change `2.0` to the desired number of seconds.
           // Code you want to be delayed
            self.PlaySound[tag] = 0
            self.myTable.reloadData()
        }
    }
    
    func didPressButton(_ tag: Int) {
        print("I have pressed a button with a tag: \(tag)")
        
        //Add love list to SubRealm
        let realm = try! Realm()
        // edit
        if listClass[tag].LoveList == 0{
          try! realm.write {
             listClass[tag].LoveList = 1
         }
        } else {
            try! realm.write {
                listClass[tag].LoveList = 0
            }
        }
        //find data in SubRealm
//        print("Language: \(listClass[tag].Language)")
        
        let eventResults = realm.objects(MClass.self).filter("Language == %@", listClass[tag].Language)
        print(eventResults)
        
        //Add love list to Realm
        if eventResults[0].LoveList == 0{
          try! realm.write {
             eventResults[0].LoveList = 1
         }
        } else {
            try! realm.write {
                eventResults[0].LoveList = 0
            }
        }
        
        self.myTable.reloadData()

    }
    
    var player:AVAudioPlayer!
    var PlaySound:[Int] = []     // nút phát âm thanh
    var LoveList = [Int]()
    var listClass = [SubMClass]()
    var play = 0
    var i = 1
    var playAll = 0
    var timer : Timer?
    let UIUX = UIUXViewController()
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? "" //setObject
    //let ipRound = "172.16.9.149"
    
    @IBOutlet weak var ttLBL: UILabel!
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var PlayButton: UIButton!
    @IBOutlet weak var TestSpeakingLbl: UIButton!
    @IBOutlet weak var ReadListenLbl: UIButton!
    @IBOutlet weak var TestListenLbl: UIButton!
    //var mang = [SubMClass]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //get title data
        
        ttLBL.text = UserDefaults.standard.string(forKey: "TitleLBL")
        
        
        UserDefaults.standard.set(1, forKey: "Back")
        
        //SET UI
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)

        //DONE UI
        
        myTable.delegate = self
        myTable.dataSource = self
        self.addData()
        self.myTable.reloadData()
        
        //không quản được thì cấm :))
        if listClass.count <= 0 {
            ReadListenLbl.isEnabled = false
            TestSpeakingLbl.isEnabled = false
            TestListenLbl.isEnabled = false
            PlayButton.isEnabled = false
        }else{
            ReadListenLbl.isEnabled = true
            TestSpeakingLbl.isEnabled = true
            TestListenLbl.isEnabled = true
            PlayButton.isEnabled = true
        }
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
        
    }
    
    @IBAction func Backbtn(_ sender: Any) {
        quayveManhinhcuthe("HomeView")
    }
    @IBAction func AddFullLoveList(_ sender: Any) {

        quayveManhinhcuthe("alert")
        
    }

    @IBAction func SearchBtn(_ sender: Any) {
        quayveManhinhcuthe("SearchView")
        
    }

    @IBAction func ReadListen(_ sender: Any) {
        
        quayveManhinhcuthe("ReadListen")
    }
    
    @objc func changeText(){
        self.PlaydidPressButton(i)
        if i < PlaySound.count - 1 {
            i += 1
        } else {
            PlayButton.setImage(UIImage(named: "play-button-2.png"), for: .normal)
            i = 1
            timer?.invalidate()
        }
    }
    
    @IBAction func PlayBtn(_ sender: Any) {
        //dừng tất cả bài đang phát trước đó
        
        if player != nil{
            try player.stop()
        }
        
        
        if playAll == 0 {
            
        print("RUNRUNRUN")
        PlayButton.setImage(UIImage(named: "play-button-3.png"), for: .normal)
        self.PlaydidPressButton(0)
        timer =  Timer.scheduledTimer(timeInterval: 2.0, target: self, selector:#selector(MainViewController.changeText), userInfo: nil, repeats: true)
            playAll = 1
        }else if playAll == 1 {
            PlayButton.setImage(UIImage(named: "play-button-2.png"), for: .normal)
            i = 1
            playAll = 0
            timer?.invalidate()
        }

    }
    
    @IBAction func TestListen(_ sender: Any) {
        
        quayveManhinhcuthe("TestListen")
    }
    
    
    @IBAction func TestSpeaking(_ sender: Any) {
        
        quayveManhinhcuthe("TestSpeaking")
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // lấy dữ liệu trong realm ra
//        self.listClass = MClass.getListMClass()
        //tạo cột
        return listClass.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! MainTableViewCell
        
        //cell UI
//        cell.CellUI.layer.insertSublayer(UIUX.CellGradient(width:Int(cell.CellUI.frame.size.width), heigh: Int(cell.CellUI.frame.size.height)), at: 0)
//        cell.CellUI.layer.borderWidth = 0.5
//        cell.CellUI.layer.borderColor = #colorLiteral(red: 0.6352941176, green: 0.4980392157, blue: 0.4588235294, alpha: 1)
        
        //done
        
        //Chọn 1 button trong cell đó
        cell.cellDelegate = self //ngôi sao
        cell.PlaycellDelegate = self//phát âm
        cell.btn.tag = indexPath.row    //ngôi sao
        cell.PlayBtn.tag = indexPath.row//phát âm
        DispatchQueue.main.async {
            
            let itemData = self.listClass[indexPath.row]
             cell.Language.text = itemData.Language
            cell.Spelling.text = itemData.Spelling
            cell.Meaning.text = itemData.Meaning
               
        
            //Love list 
            if itemData.LoveList == 0 {
                //set button image
                cell.btn.setImage(UIImage(named: "AddList"), for: .normal)
            }else{
                cell.btn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
                
            }
            
            //Thay đổi hình ảnh nút âm thanh
            if self.PlaySound.count > 0 {
            if self.PlaySound[indexPath.row] == 1 {
                //phát
                cell.PlayBtn.setImage(UIImage(named: "play-button-4"), for: .normal)
                
            }else {
                cell.PlayBtn.setImage(UIImage(named: "SoundBig"), for: .normal)
            }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 94;//Choose your custom row height
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        UserDefaults.standard.set(self.listClass[indexPath.row].Language, forKey: "Test")
        print("VALUE:: \(self.listClass[indexPath.row].Language)")

        quayveManhinhcuthe("TestSpeaking")
    }
    
    func addData(){
        
        //DispatchQueue.main.sync {
        // lấy dữ liệu trong realm ra
        //nếu trong real không có dữ liệu
            //self.listClass = SubMClass.getListMClass()
        self.listClass = SubMClass.getListMClass()
            //add tìm kiếm
            //mang = self.listClass
            
            //self.myTable.reloadData()
        //}
    }


}


