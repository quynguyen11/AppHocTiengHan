//
//  FlashCardTableViewCell.swift
//  Korean Language
//
//  Created by QuangTran on 12/10/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
protocol FlashCardCellDelegate : class{
    func addOrSeeFlashCard(_ tag: Int)
}
class FlashCardTableViewCell: UITableViewCell {

    @IBOutlet weak var LanguageLbl: UILabel!
    @IBOutlet weak var CreateOrView: UIButton!
    
    var cellDelegate: FlashCardCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func PressFlashCard(_ sender: UIButton) {
        cellDelegate?.addOrSeeFlashCard(sender.tag)
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
