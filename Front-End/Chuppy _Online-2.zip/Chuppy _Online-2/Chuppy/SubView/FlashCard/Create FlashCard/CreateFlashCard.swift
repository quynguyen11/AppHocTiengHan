//
//  ViewController.swift
//  photoSearch
//
//  Created by Мария on 10.10.2019.
//  Copyright © 2019 Мария. All rights reserved.
//

import UIKit
import RealmSwift

@available(iOS 13.0, *)
@available(iOS 13.0, *)
class CreateFlashCard: UIViewController {


    @IBOutlet weak var ImageView: UIImageView!
    
    @IBOutlet weak var loader: UIActivityIndicatorView!
    
    @IBOutlet weak var textField: UILabel!
    
    @IBOutlet weak var NotificationLbl: UILabel!
    
    @IBOutlet weak var SaveImage: UIButton!
    
    let realm = try! Realm()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.text = UserDefaults.standard.string(forKey: "FlashCard")
        SaveImage.isEnabled = false
        //textField.delegate = self
        NotificationLbl.isHidden = true
        //textField.becomeFirstResponder()
        ImageView.layer.masksToBounds = true
        searchImage(text: textField.text ?? "")
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
    }
    
    @IBAction func quit(_ sender: Any) {
        quayveManhinhcuthe("FlashCardTable")
    }
    @IBAction func SaveImage(_ sender: Any) {
        
        //get id letter
        let filter = realm.objects(MClass.self).filter("Language == %@", textField.text ?? "")
        
        //save letter
        saveImage(image: ImageView.image!, FileName: filter[0].name )
        let documentDirectoryPath:String = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        print("PATH URL: \(documentDirectoryPath)")
        SaveImage.isEnabled = false
    }
    ///Save Image
    func saveImage(image: UIImage, FileName: String) -> Bool {
        guard let data = image.jpegData(compressionQuality: 1) ?? image.pngData() else {
            return false
        }
        guard var directory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) as NSURL else {
            return false
        }
        do {
            directory = directory.appendingPathComponent( "/FlashCard", isDirectory: true )! as NSURL

            try data.write(to: directory.appendingPathComponent("\(FileName).png")!)
            return true
        } catch {
            print(error.localizedDescription)
            return false
        }
    }
    
    ///

    func convert(farm: Int, server: String, photoId: String, secret: String) -> URL? {
        let url = URL(string: "https://farm\(farm).staticflickr.com/\(server)/\(photoId)_\(secret)_c.jpg")!
        return url
    }

    func showError(_ text: String) {
        let alert = UIAlertController(title: "Error", message: text, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default)
        alert.addAction(okButton)
        DispatchQueue.main.async {
            self.present(alert, animated: true)
        }
    }
    
    func showLoader(_ show: Bool) {
        DispatchQueue.main.async {
            if show {
                self.ImageView.image = nil
                self.loader.startAnimating()
            } else {
                self.loader.stopAnimating()
            }
        }
    }
    
    func searchImage(text: String) {
        //
        showLoader(true)
        
        let base = "https://www.flickr.com/services/rest/?method=flickr.photos.search"
        let key = "&api_key=565bec242644bb4ee0bdc51fbde270f4"
        let format = "&format=json&nojsoncallback=1"
        
        let formattedText = text.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? ""
        
        let textToSearch = "&text=\(formattedText)"
        let sort = "&sort=relevance"

        let searchUrl = base + key + format + textToSearch + sort
        let url = URL(string: searchUrl)!
        URLSession.shared.dataTask(with: url) { (data, _, _) in
            print("ONE")
            guard let jsonData = data else{
                self.showError("not enough data")
                return
            }
            print("TWO")
            guard let jsonAny = try? JSONSerialization.jsonObject(with: jsonData, options: []) else {
                self.showError("error: no json")
                self.showLoader(false)
                return
            }
            print(jsonAny)
            print("THREE")
            guard let json = jsonAny as? [String: Any] else {
                self.showLoader(false)
                return
            }
            print("FOUR")
            guard let photos = json["photos"] as? [String: Any] else {
                return
            }
            print("FIVE")
            guard let photosArray = photos["photo"] as? [Any] else {
                self.showLoader(false)
                return
            }
            print("SIX")
            guard photosArray.count > 0 else {
                DispatchQueue.main.async{
                    
                    self.SaveImage.isEnabled = true
                    self.NotificationLbl.isHidden = false
                    
                    self.ImageView.image = UIImage.init(named: "BlankImage.png")
                //can not find any photo for flashcard
                let s2 = NSAttributedString(string: self.textField.text ?? "", attributes:
                            [.font:UIFont(name: "Georgia", size: 60)!,
                             .foregroundColor: UIColor.black])
                
                let sz = self.ImageView.image!.size
                        let r = UIGraphicsImageRenderer(size:sz)
                self.ImageView.image = r.image {
                            _ in
                    self.ImageView.image!.draw(at:.zero)
                            s2.draw(at: CGPoint(x:30, y:sz.height-150))
                        }
                //ImageView.
                    
                
                //self.showError("No photod found. Generate photo !")
                //self.saveImage(image: self.ImageView.image!, FileName: self.textField.text ?? "")
                }
                self.showLoader(false)
                
                
                
                return
            }
            //only get ONE photo
            guard let firstPhoto = photosArray[0] as? [String: Any] else {
                return
            }
            let farm = firstPhoto["farm"] as! Int
            let photoId = firstPhoto["id"] as! String
            let secret = firstPhoto["secret"] as! String
            let server = firstPhoto["server"] as! String
            
            let pictureUrl = self.convert(farm: farm, server: server, photoId: photoId, secret: secret)!
            
            URLSession.shared.dataTask(with: pictureUrl, completionHandler: { (data, _, _) in
                DispatchQueue.main.async {
                    ///Load Done
                    self.ImageView.image = UIImage(data: data!)
                    self.showLoader(false)
                    self.SaveImage.isEnabled = true
                    /// Save picture to phone
                    print("Frame: \(farm)")
                    print("photoId: \(photoId)")
                    print("secret: \(secret)")
                    print("server: \(server)")
                    
                }
            }).resume()
        }.resume()
        ////Done
        
    }
}

//extension CreateFlashCard: UITextFieldDelegate {
//    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//        searchImage(text: textField.text!)
//        return true
//    }
//}

