//
//  FlashCardTable.swift
//  Korean Language
//
//  Created by QuangTran on 12/10/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation
import UIKit
import Realm
@available(iOS 13.0, *)
class FlashCardTable: UIViewController, UITableViewDelegate, UITableViewDataSource, FlashCardCellDelegate{
    func addOrSeeFlashCard(_ tag: Int) {
        print("I have pressed a play button (MainView) with a tag: \(tag)")
        
        let filter = execute.filter{ $0.contains("\(tag)")}
        print("FILTERRRRRR: \(filter)")
        
        UserDefaults.standard.set(listClass[tag].Language, forKey: "FlashCard") //setObject
        if filter.count <= 0 {
            quayveManhinhcuthe("CreateFlashCard")
        }else{
            quayveManhinhcuthe("ViewFlashCard")
        }
    }
    
    
    var listClass = [MClass]()
    var getFileName: [String] = []
    var PhotoName: [String] = []
    var execute: [String] = []
    let UIUX = UIUXViewController()
    @IBOutlet weak var myTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set UI/UX
        
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)
        
        self.myTable.backgroundColor = UIUXViewController().UIBackGround
        
        myTable.delegate = self
        myTable.dataSource = self
        loadData()
        self.myTable.reloadData()
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
    }
    
    
    func loadData(){
        listClass = MClass.getListMClass()
        
        //create folder if it not exist
        let DocumentDirectory = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        let DirPath = DocumentDirectory.appendingPathComponent("FlashCard")
        do
        {
            try FileManager.default.createDirectory(atPath: DirPath!.path, withIntermediateDirectories: true, attributes: nil)
        }
        catch let error as NSError
        {
            print("Unable to create directory \(error.debugDescription)")
        }
        print("Dir Path = \(DirPath!)")
        
        
        
        //get data from file manager
        let documentDirectoryPath:String = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
            let myFilesPath = "\(documentDirectoryPath)/FlashCard"
            let filemanager = FileManager.default
            let files = filemanager.enumerator(atPath: myFilesPath)
            while let file = files?.nextObject() {
                let filterNormal = "\(file)".components(separatedBy: ".")
                //print(filterNormal[0])
                getFileName.append(filterNormal[0])
            }
        
    }
    @IBAction func BackBtn(_ sender: Any) {
        getFileName.removeAll()
        quayveManhinhcuthe("HomeView")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        listClass.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! FlashCardTableViewCell
        
        cell.cellDelegate = self //ngôi sao
        cell.CreateOrView.tag = indexPath.row
        
        DispatchQueue.main.async {
            cell.LanguageLbl.text = self.listClass[indexPath.row].Meaning
            
            //button show
            let fil = self.listClass[indexPath.row].name
            let filter = self.getFileName.filter{$0.contains(fil) && $0.count == fil.count }
            print("FILTER: \(filter)")

            if filter.count != 0{
                cell.CreateOrView.setTitle("View Flash Card", for: .normal)
                self.execute.append("\(indexPath.row)")
            }else{
                cell.CreateOrView.setTitle("Create Flash Card", for: .normal)
            }
            
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140;//Choose your custom row height
    }
    
    
    
}
