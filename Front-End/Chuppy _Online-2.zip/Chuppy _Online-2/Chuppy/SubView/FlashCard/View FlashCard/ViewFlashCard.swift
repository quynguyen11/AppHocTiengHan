//
//  ViewFlashCard.swift
//  Korean Language
//
//  Created by QuangTran on 12/11/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

@available(iOS 13.0, *)
class ViewFlashCard: UIViewController {
    
    
    @IBOutlet weak var LanguageMain: UILabel!
    @IBOutlet weak var ImageFlashCard: UIImageView!
    @IBOutlet weak var MeaningMain: UILabel!
    @IBOutlet weak var SpellingMain: UILabel!
    @IBOutlet weak var ShowOrHiddenLbl: UIButton!
    @IBOutlet weak var LanguageAns: UILabel!
    
    var letters = ""
    let Language = UserDefaults.standard.string(forKey: "FlashCard")
    var mang: [MClass] = []
    let realm = try! Realm()
    var show = false
    var idName: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LanguageAns.isHidden = true
        ShowOrHiddenLbl.setTitle("Show Card", for: .normal)
        loadData()
        ImageFlashCard.isHidden = true
        
    }
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        //self?.image = image
                        self?.ImageFlashCard.image = image
                    }
                }
            }
        }
    }
    
    @IBAction func ShowOrHidden(_ sender: Any) {
        
        if show == false{
            ImageFlashCard.isHidden = false
            LanguageAns.isHidden = false
            show = true
            ShowOrHiddenLbl.setTitle("Hidden Card", for: .normal)
        }else{
            ImageFlashCard.isHidden = true
            LanguageAns.isHidden = true
            show = false
            ShowOrHiddenLbl.setTitle("Show Card", for: .normal)
        }
        
        
    }
    
    @IBAction func quit(_ sender: Any) {
        quayveManhinhcuthe("FlashCardTable")
    }
    
    func loadData(){
        
        //get from MClass
        let filter = realm.objects(MClass.self).filter("Language == %@", Language as Any)
        letters = filter[0].Language
        
        LanguageMain.text = filter[0].Language
        MeaningMain.text = filter[0].Meaning
        SpellingMain.text = filter[0].Spelling
        LanguageAns.text = filter[0].Language
        idName = filter[0].name
        
        if let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
        let imgText: String = "FlashCard/" + idName + ".png"
        let fileURL = documentsUrl.appendingPathComponent(imgText)
            
        print("CARDCARD: \(fileURL)")
            load(url: fileURL)
        }
        
        //modify ChuHan
        formatUserGuessLabel()
        
        
    }
    
    func formatUserGuessLabel() {
        
        let letters = LanguageMain.text ?? ""
        
        var n = 0
        var newLetter = ""
        for letter in letters{
            if n % 2 != 0{
                newLetter = newLetter + "\(letter)"
            }else{
                newLetter += " _"
            }
            n += 1
        }
        newLetter.removeFirst()
        LanguageMain.text = newLetter
        
    }
}
