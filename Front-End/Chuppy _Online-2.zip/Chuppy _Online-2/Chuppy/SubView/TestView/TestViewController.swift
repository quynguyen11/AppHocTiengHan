//
//  TestViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 9/10/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import AVFoundation
import RealmSwift

@available(iOS 13.0, *)
class TestViewController: UIViewController {
    
    //data
    var Scores: Int = 0
    var Percents: Int = 0
    var CountWrong: Int = 0
    var Answers: String = ""
    //Dữ liệu vào
    var Questions: [String] = []
    var InlineQuestions: [String] = []
    var CorrectBtn: UIButton!
    var countss: Int = 0
    //var listClass: MClass
    var ModelTest = Test()
    var mang = [MClass]()
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? ""
    var player:AVAudioPlayer!
    let realm = try! Realm()
    var sound: String = ""
    var random: String = ""
    let UIUX = UIUXViewController()
    //Btn1: Right; Btn2: Wrong

    @IBOutlet weak var Btn1txt: UIButton!
    @IBOutlet weak var Btn2txt: UIButton!
    @IBOutlet weak var Btn3txt: UIButton!
    @IBOutlet weak var Btn4txt: UIButton!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var Score: UILabel!
    @IBOutlet weak var Percent: UILabel!
    @IBOutlet weak var LanguageLbl: UILabel!
    @IBOutlet weak var MeaningLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)

        //DONE UI
        
        //print("RunRunRun")

        // Do any additional setup after loading the view.
        self.progressView.progress = 0.0
        
        NotificationCenter.default.post(name: NSNotification.Name("viewLoaded"), object: nil)
       
        ModelTest.addData()
        
        for match in ModelTest.mang{
            Questions.append(match.Spelling)
        }
        GenerateQuestion()
        
        print( "IP Play Music: "+"\(ipRound)/upload/")
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
        
    }

    
    @IBAction func BackBtn(_ sender: Any) {
         //stop old audio
        if player != nil{
            try player.stop()
        }
        
        quayveManhinhcuthe("HomeView")
    }
    @IBAction func Btn1(_ sender: Any) {
        Check(txt: Btn1txt.titleLabel?.text ?? "", WrongBtn: Btn1txt)
        
    }
    
    @IBAction func Btn2(_ sender: Any) {
        Check(txt: Btn2txt.titleLabel?.text ?? "", WrongBtn: Btn2txt)
    }
    
    
    @IBAction func Btn3(_ sender: Any) {
        Check(txt: Btn3txt.titleLabel?.text ?? "", WrongBtn: Btn3txt)
    }
    
    
    @IBAction func Btn4(_ sender: Any) {
        Check(txt: Btn4txt.titleLabel?.text ?? "", WrongBtn: Btn4txt)
    }
    
    
    @IBAction func SpeechBtn(_ sender: Any) {
        
        print("IP Play Music: " + ipRound)
        print( "IP Play Music: "+"\(ipRound)/upload/" + sound)
        
        let url:URL = URL(string: "\(ipRound)/upload/" + sound)!
         do{
             let data:Data = try Data(contentsOf: url)
             player = try AVAudioPlayer(data: data)
            player.play()
             //player.stop()
        }catch
        {
            print("Loi phat nhac")
        }
        
    }
    
    //function check right or wrong
    func Check(txt: String, WrongBtn: UIButton){
        
        //txt là chữ đúng
        if txt == Answers{
            CorrectBtn.backgroundColor = UIColor.init(red: 255/255, green: 158/255, blue: 159/255, alpha: 1)
            //score (Cộng điểm)
            Scores = Scores + 1
            Score.text = String(Scores)
            //progressBar
            self.progressView.progress = self.progressView.progress + 0.1
            //percent
            Percents = Percents + 10
            Percent.text = String(Percents) + "%"
            
            //Default Button
            WrongBtn.backgroundColor = nil
            CountWrong = 0
            
            //tạo ra bộ câu hỏi mới
            Btn1txt.titleLabel?.text = nil
            Btn2txt.titleLabel?.text = nil
            Btn3txt.titleLabel?.text = nil
            Btn4txt.titleLabel?.text = nil
            countss = countss + 1
            InlineQuestions.removeAll()
            //nếu đã đủ 10 câu
            if Scores == 10 {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let secondVC = storyboard.instantiateViewController(identifier: "HomeView")
                
                secondVC.modalPresentationStyle = .fullScreen
                secondVC.modalTransitionStyle = .coverVertical
                
                present(secondVC, animated: true, completion: nil)
            }
            
            GenerateQuestion()
            
        }
        else {
            WrongBtn.backgroundColor = UIColor.init(red: 162/255, green: 127/255, blue: 117/255, alpha: 1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                // Change `2.0` to the desired number of seconds.
               // Code you want to be delayed
                WrongBtn.backgroundColor = nil
            }
            CorrectBtn.backgroundColor = nil
            //trừ điểm
            if Scores > 0{
                Scores = Scores - 1
            }
            Score.text = String(Scores)
            //progressBar
            if self.progressView.progress > 0 {
                self.progressView.progress = self.progressView.progress - 0.1
            }
            //percent
            if Percents > 0 {
                Percents = Percents - 10
                Percent.text = String(Percents) + "%"
            }
            //nếu đánh sai 5 lần 
            CountWrong = CountWrong + 1
            if CountWrong >= 3 {
                CorrectBtn.backgroundColor = UIColor.init(red: 255/255, green: 158/255, blue: 159/255, alpha: 1)
            }

        }
        
    }
    func GenerateQuestion(){
        
        //tạo mảng nhỏ đưa 4 đáp án bất kỳ (luôn có 1 đáp án đúng)
        var i = 0
        while i < 4 {
            
            //Khởi tạo câu hỏi
            var count = Questions.count
                random = Questions[Int.random(in: 0..<count)]

            //xét nếu trùng đáp án thì ko cho đưa vào
            var flag = 0
            for n in 0..<InlineQuestions.count{
                
                if InlineQuestions[n] == random {
                    
                    flag = 1
                }
            }
            if flag == 0 {
                InlineQuestions.append(random)
                 i = i + 1
            }
            
            
        }
        
        //Khởi tạo câu trả lời
        Answers = InlineQuestions[Int.random(in: 0..<InlineQuestions.count)]
        print("Anws: ", Answers)
        //add answers sound
        //find
        //add tìm kiếm
        
        let info = realm.objects(MClass.self).filter("Spelling = %@", Answers)
        
        print("Sound: \(info.first?.Media ?? "")")
        sound = "\(info.first?.Media ?? "")"
        
        //add chữ hàn và nghĩa vào
        LanguageLbl.text = info.first?.Language
        MeaningLbl.text = info.first?.Meaning
        
        ///////////
        
        //add câu đúng vào trước
//        InlineQuestions.append(Answers)
        
        
        print(InlineQuestions)
        
        //đưa mảng nhỏ đó vào button
        //Tạo cho

        Btn1txt.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
        //print("\(countss) Add1: \(InlineQuestions)")
        //xoá đi phần tử vừa tạo
        //print("\(countss) Btn1txt: \(Btn1txt.titleLabel?.text ?? "")")
        RemoveElement(itemToRemoves: Btn1txt.titleLabel?.text ?? "")
        
        
        Btn2txt.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
//        print("\(countss) Add2: \(InlineQuestions)")
//        print("\(countss) Btn2txt: \(Btn2txt.titleLabel?.text ?? "")")
        RemoveElement(itemToRemoves: Btn2txt.titleLabel?.text ?? "")
        
        Btn3txt.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
//        print("\(countss) Add3: \(InlineQuestions)")
//        print("\(countss) Btn3txt: \(Btn3txt.titleLabel?.text ?? "")")
        RemoveElement(itemToRemoves: Btn3txt.titleLabel?.text ?? "")
        
        Btn4txt.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
//        print("\(countss) Add4: \(InlineQuestions)")
//        print("\(countss) Btn4txt: \(Btn4txt.titleLabel?.text ?? "")")
        
        //đưa button đúng vào
        if Btn1txt.titleLabel?.text == Answers{
            CorrectBtn = Btn1txt
        }else if Btn2txt.titleLabel?.text == Answers{
            CorrectBtn = Btn2txt
        }else if Btn3txt.titleLabel?.text == Answers{
            CorrectBtn = Btn3txt
        }else if Btn4txt.titleLabel?.text == Answers{
            CorrectBtn = Btn4txt
        }
        
        
    }
    func RemoveElement(itemToRemoves:String){
        let itemToRemove = itemToRemoves

        while InlineQuestions.contains(itemToRemove) {
            if let itemToRemoveIndex = InlineQuestions.firstIndex(of: itemToRemove) {
                InlineQuestions.remove(at: itemToRemoveIndex)
            }
        }

        
    }
    
}
