//
//  ModelTest.swift
//  Korean Language
//
//  Created by Quang Tran on 9/24/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation

class Test{
    
    var cau1: String = "Modeltest"
    var listClass = [MClass]()
    var mang = [MClass]()
    
    
    func addData(){
        
        // lấy dữ liệu trong realm ra
        if listClass.count <= 0 {
            self.listClass = MClass.getListMClass()
            //add tìm kiếm
            mang = self.listClass
            //print("::", mang)
        }
    }

    
}
