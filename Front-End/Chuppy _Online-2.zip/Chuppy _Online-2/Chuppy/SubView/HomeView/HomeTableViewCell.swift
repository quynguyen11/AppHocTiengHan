//
//  MenuTableViewCell.swift
//  Korean Language
//
//  Created by Quang Tran on 8/29/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit

protocol TestCellDelegate : class {
    func pressTestPlayBtn(_ tag: Int)
    func pressRecordTestPlayBtn(_ tag: Int)
    func pressLearnWordPlayBtn(_ tag: Int)
}

class HomeTableViewCell: UITableViewCell {

    var TestYourCellDelegate: TestCellDelegate?
    @IBOutlet weak var Language: UILabel!
    @IBOutlet weak var Meaning: UILabel!
    
    @IBOutlet weak var cellOutLet: UIView!
    @IBOutlet weak var ViewMenuCell: UIImageView!
    @IBOutlet weak var sttLbl: UIImageView!
    

    @IBOutlet weak var TestBtn: UIButton!
    @IBOutlet weak var RecodTestBtn: UIButton!
    @IBOutlet weak var LearnWordBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //ui/ux
        self.cellOutLet.backgroundColor = UIUXViewController().UIBackGround
        
        // Initialization code
    }
    @IBAction func TestPlayBtn(_ sender: UIButton) {
        TestYourCellDelegate?.pressTestPlayBtn(sender.tag)
        
    }
    
    @IBAction func RecordTestPlayBtn(_ sender: UIButton) {
        TestYourCellDelegate?.pressRecordTestPlayBtn(sender.tag)
    }
    
    @IBAction func LearnWordPlayBtn(_ sender: UIButton) {
        TestYourCellDelegate?.pressLearnWordPlayBtn(sender.tag)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
