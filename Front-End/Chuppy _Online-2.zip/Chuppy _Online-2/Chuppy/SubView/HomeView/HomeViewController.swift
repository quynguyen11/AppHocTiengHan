//
//  MenuViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 8/29/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift


@available(iOS 13.0, *)
class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TestCellDelegate {
    func pressTestPlayBtn(_ tag: Int) {
        print("Press: \(tag)")
        SelectSubData(catagory: tag)
        quayveManhinhcuthe("TestViewScreen")
        
    }
    
    func pressRecordTestPlayBtn(_ tag: Int) {
        UserDefaults.standard.set("", forKey: "Test")
        SelectSubData(catagory: tag)
        //create database
        quayveManhinhcuthe("TestSpeaking")
    }
    
    func pressLearnWordPlayBtn(_ tag: Int) {
        SelectSubData(catagory: tag)
        quayveManhinhcuthe("ReadListen")
    }
    
    
    let data = DataDulieu()
    var listClass = [MClass]()
    var SublistClass = [SubMClass]()
    var mang = [Dulieu]()
    var hidden = true
    var number = 1
    var titleLBL:String?
    let UIUX = UIUXViewController()
    var count = 0

    @IBOutlet weak var HidBtn: UIButton!
    @IBOutlet var PanBtn: UIPanGestureRecognizer!
    @IBOutlet weak var sideView: UIView!
    @IBOutlet weak var viewConstraint: NSLayoutConstraint!
    @IBOutlet weak var myTable: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UserDefaults.standard.set(0, forKey: "Back")
        
        //set UI/UX
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)
        
        self.myTable.backgroundColor = UIUXViewController().UIBackGround
        //self.sideView.layer.mask = gradient
        //Done UI/UX
        
        print(Realm.Configuration.defaultConfiguration.fileURL!)
        
        //Menu slide
        viewConstraint.constant = -289

            DispatchQueue.main.async {
                //MongoDB.loadData()
                let db = MongoDB()  //new init
                db.loadData()
            }
        
        myTable.delegate = self
        myTable.dataSource = self
        mang = data.Language
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)

    }

    @IBAction func SearchBtn(_ sender: Any) {
        //add data
        //Delete old
        let realm = try! Realm()
         let found = realm.objects(SubMClass.self)

         try! realm.write {
             realm.delete(found)
         }
        
        //Add data
        //get from MClass
               let eventResults = realm.objects(MClass.self)
               //print(eventResults)
        if eventResults.count > 0 {
               for n in 0...eventResults.count - 1{

               //thêm vào realm
               //mỗi lần chạy phải khai báo lại data2
               let data2 = SubMClass()
               data2.LoveList = eventResults[n].LoveList
               data2.Language = eventResults[n].Language
               data2.Spelling = eventResults[n].Spelling
               data2.Meaning = eventResults[n].Meaning
               data2.Media = eventResults[n].Media
               data2.Types = eventResults[n].Types
               
               //thêm dữ liệu vào CSDL
                   try! realm.write {
                        realm.add(data2)
                }
               //khởi tạo PlaySound
               }
        }

        quayveManhinhcuthe("SearchView")
    }
    
    @IBAction func LoveListBtn(_ sender: Any) {
        
        //Delete old
        let realm = try! Realm()
         let found = realm.objects(SubMClass.self)

         try! realm.write {
             realm.delete(found)
         }
        
        //Add data
        //get from MClass
               let eventResults = realm.objects(MClass.self).filter("LoveList == %@", 1)
               //print(eventResults)
        if eventResults.count > 0{
               for n in 0...eventResults.count - 1{

               //thêm vào realm
               //mỗi lần chạy phải khai báo lại data2
               let data2 = SubMClass()
               data2.LoveList = eventResults[n].LoveList
               data2.Language = eventResults[n].Language
               data2.Spelling = eventResults[n].Spelling
               data2.Meaning = eventResults[n].Meaning
               data2.Media = eventResults[n].Media
               data2.Types = eventResults[n].Types
               
               //thêm dữ liệu vào CSDL
                   try! realm.write {
                        realm.add(data2)
                }
               //khởi tạo PlaySound
               }
        }
        
        quayveManhinhcuthe("SearchView")
    }
    
    @IBAction func WritingBtn(_ sender: Any) {
        quayveManhinhcuthe("Writing")
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mang.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! HomeTableViewCell

        //chon 1 button
        //không quản được thì cấm :))
        if mang.count <= 0 {
            cell.TestBtn.isEnabled = false
            cell.RecodTestBtn.isEnabled = false
        }else{
            cell.TestBtn.isEnabled = true
            cell.RecodTestBtn.isEnabled = true
        }
        
        
        cell.TestYourCellDelegate = self
        cell.TestBtn.tag = indexPath.row
        cell.RecodTestBtn.tag = indexPath.row
        cell.LearnWordBtn.tag = indexPath.row
        
        DispatchQueue.main.async {
            cell.Language.text = self.mang[indexPath.row].Language
            cell.Meaning.text = self.mang[indexPath.row].Meaning
            cell.sttLbl.image = UIImage(named: self.mang[indexPath.row].img)
        }
        
        //không quản được thì cấm :))
        if SubMClass.getListMClass().count <= 0 {
            cell.TestBtn.isEnabled = false
            cell.RecodTestBtn.isEnabled = false
        }else{
            cell.TestBtn.isEnabled = true
            cell.RecodTestBtn.isEnabled = true
        }

                return cell
    }
    
    @IBAction func Writting(_ sender: Any) {
        //Gramma
        UserDefaults.standard.set("gram", forKey: "VocaOrGram")
        quayveManhinhcuthe("VocabularyOrGramma")
    }
    
    @IBAction func Vocabulary(_ sender: Any) {
        //Vocabulary
        UserDefaults.standard.set("voca", forKey: "VocaOrGram")
        quayveManhinhcuthe("VocabularyOrGramma")
    }
    @IBAction func VideoPractice(_ sender: Any) {
        UserDefaults.standard.set("VIDEO", forKey: "VocaOrGram")
        quayveManhinhcuthe("VocabularyOrGramma")
    }
    @IBAction func Game_WordSearch(_ sender: Any) {
        quayveManhinhcuthe("GameVC")
    }
    
    @IBAction func Game_WordGarden(_ sender: Any) {
        quayveManhinhcuthe("WordGarden")
    }
    @IBAction func FlashCardBtn(_ sender: Any) {
        quayveManhinhcuthe("FlashCardTable")
    }
    
    
    @IBAction func Author(_ sender: Any) {
        quayveManhinhcuthe("Author")
    }
    
    @IBAction func HiddenMenu(_ sender: Any) {
        UIView.animate(withDuration: 0.5,
                       delay: 0.0,
                       options: [],
                       animations: {
                        self.viewConstraint.constant += 289
                        self.view.layoutIfNeeded()
                       })
        
    }
    
    @IBAction func panPerformed(_ sender: UIPanGestureRecognizer) {
        
        if sender.state == .began || sender.state == .changed {
            
            let translation = sender.translation(in: self.view).x
            
            if translation > 0 {    //swipe right
                
                if viewConstraint.constant < 20 {
                    UIView.animate(withDuration: 0.2, animations: {
                        
                        self.viewConstraint.constant += translation / 10
                        self.view.layoutIfNeeded()
                    })
                }
            }else{  //swipe left
                if viewConstraint.constant > -289 {
                UIView.animate(withDuration: 0.2, animations: {
                    
                    self.viewConstraint.constant += translation / 10
                    self.view.layoutIfNeeded()
                })
            }
            }
        }else if sender.state == .ended {
            if viewConstraint.constant < -100 {
                UIView.animate(withDuration: 0.2, animations: {
                    self.viewConstraint.constant = -289
                    self.view.layoutIfNeeded()
                })
            }else {
                UIView.animate(withDuration: 0.2, animations: {
                    self.viewConstraint.constant = 0
                    self.view.layoutIfNeeded()
                })
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 137;//Choose your custom row height
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
        //co update moi thi xoa cai cu
        SelectSubData(catagory: indexPath.row)
               //add data
        quayveManhinhcuthe("ChuHan")
    }
    
    func SelectSubData(catagory: Int){
        //co update moi thi xoa cai cu
               let realm = try! Realm()

               //Delete old
                let found = realm.objects(SubMClass.self)

                try! realm.write {
                    realm.delete(found)
                }
               //
               if catagory == 0 {
                   //Hello
                   //DispatchQueue.main.async {
                       self.CreateSubRealm(sub: "인사")
                titleLBL = "인사"
                   //}
               }
               if catagory == 1 {
                   //School
                       self.CreateSubRealm(sub: "일반회화")
                titleLBL = "일반회화"
               }
               if catagory == 2 {
                   //Company
                       self.CreateSubRealm(sub: "민수기")
                titleLBL = "민수기"
               }
               if catagory == 3 {
                   //Park
                       self.CreateSubRealm(sub: "Park")
                titleLBL = "Park"
               }
               if catagory == 4 {
                   //Shop
                       self.CreateSubRealm(sub: "Shop")
                titleLBL = "Shop"
               }
        UserDefaults.standard.set(titleLBL, forKey: "TitleLBL")
               print("row: \(catagory)")
    }
    
    func CreateSubRealm(sub: String){
        
        let realm = try! Realm()
        
        //get from MClass
        let eventResults = realm.objects(MClass.self).filter("Types == %@", sub)
        print(eventResults)
        if eventResults.count > 0 {
        for n in 0...eventResults.count - 1{

        //thêm vào realm
        //mỗi lần chạy phải khai báo lại data2
        let data2 = SubMClass()
        data2.LoveList = eventResults[n].LoveList
        data2.Language = eventResults[n].Language
        data2.Spelling = eventResults[n].Spelling
        data2.Meaning = eventResults[n].Meaning
        data2.Media = eventResults[n].Media
        data2.Types = eventResults[n].Types
        
        //thêm dữ liệu vào CSDL
            try! realm.write {
                 realm.add(data2)
         }
        //khởi tạo PlaySound
        }
        }
    }


}



