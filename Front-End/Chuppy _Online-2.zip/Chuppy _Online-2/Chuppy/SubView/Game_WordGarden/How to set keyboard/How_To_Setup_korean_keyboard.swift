//
//  How_To_Setup_korean_keyboard.swift
//  Korean Language
//
//  Created by QuangTran on 12/15/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift
import AVFoundation

class How_To_Setup_Korean_Keyboard: UIViewController {
    
    @IBOutlet weak var Back: UIButton!
    @IBOutlet weak var ImageView: UIImageView!
    var imageNum = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        let UIUX = UIUXViewController()
        self.view.applyGradient(colours: [UIUX.part1, UIUX.part2], locations: [UIUX.loc1,UIUX.loc2])
        //DONE UI
        
        ImageView.image = UIImage(named: "\(imageNum)")
        
    }
    
    @IBAction func BackBtn(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func BackImage(_ sender: Any) {
        
        if imageNum <= 1 {
            imageNum = 1
        }else{
            imageNum -= 1
        }
        ImageView.image = UIImage(named: "\(imageNum)")
    }
    
    @IBAction func NextImage(_ sender: Any) {
        
        if imageNum >= 7 {
            imageNum = 7
        }else{
            imageNum += 1
        }
        ImageView.image = UIImage(named: "\(imageNum)")
    }
}
