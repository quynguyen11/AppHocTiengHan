//
//  ViewController.swift
//  Word Garden
//
//  Created by Jessica Olivieri on 9/14/18.
//  Copyright © 2018 Jessica Olivieri. All rights reserved.
//

import UIKit
import RealmSwift
import AVFoundation

@available(iOS 13.0, *)
@available(iOS 13.0, *)
class WordGarden: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessedLetterField: UITextField!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    @IBOutlet weak var flowerImageView: UIImageView!
    
    var wordToGuess = "SWIFT"
    var lettersGuessed = ""
    let maxNumberOfWrongGuesses = 8
    var wrongGuessesRemaining = 8
    var guessCount = 0
    var listClass = [MClass]()
    var sound: String = ""
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? ""
    var player:AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        let UIUX = UIUXViewController()
        self.view.applyGradient(colours: [UIUX.part1, UIUX.part2], locations: [UIUX.loc1,UIUX.loc2])
        //DONE UI
        
        loadData()
        formatUserGuessLabel()
        self.guessedLetterField.delegate = self
        //print("In viewDidLoad, is guessedLetterField the first responder?", guessedLetterField.isFirstResponder)
        //guessLetterButton.isEnabled = false
        playAgainButton.isHidden = true
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
    }
    //hid keyboard when press 'return' key
//    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//            self.view.endEditing(true)
//            return false
//        }
    
    func loadData(){
        
        self.listClass = MClass.getListMClass()
        
        //generate Question
        let count = listClass.count
        if count > 0 {
        let random = Int.random(in: 0..<count)
        wordToGuess = listClass[random].Language
        sound = listClass[random].Media
        
        print("AWS: \(wordToGuess)\n")
    }
    }
    
    @IBAction func Hint(_ sender: Any) {
        guessedLetterField.text = wordToGuess
    }
    
    @IBAction func quit(_ sender: Any) {
        //stop old audio
       if player != nil{
           try player.stop()
       }
        dismiss(animated: true, completion: nil)
    }
    @IBAction func PlaySound(_ sender: Any) {
        print("IP Play Music: " + ipRound)
         print( "IP Play Music: "+"\(ipRound)/upload/" + sound)
         
         let url:URL = URL(string: "\(ipRound)/upload/" + sound)!
          do{
              let data:Data = try Data(contentsOf: url)
              player = try AVAudioPlayer(data: data)
             player.play()
              //player.stop()
         }catch
         {
             print("Loi phat nhac")
         }
    }
    
    @IBAction func HowToSetupKeyBoard(_ sender: Any) {
        quayveManhinhcuthe("How_To_Setup_Korean_Keyboard")
    }
    
    func updateUIAfterGuess(){
        guessedLetterField.resignFirstResponder()
        guessedLetterField.text = ""
    }
    
    func formatUserGuessLabel() {
        var revealedWord = ""
        lettersGuessed += guessedLetterField.text!
        
        for letter in wordToGuess {
            if lettersGuessed.contains(letter) {
                revealedWord = revealedWord + " \(letter)"
            } else {
                revealedWord += " _"
            }
        }
        revealedWord.removeFirst()
        userGuessLabel.text = revealedWord
    }
    
    func guessALetter() {
        formatUserGuessLabel()
        guessCount += 1
        
        // decrements the wrongGuessesRemaining and shows the next flower image with one less petal
        let currentLetterGuessed = guessedLetterField.text!
        if !wordToGuess.contains(currentLetterGuessed) { //! means not guessed
            wrongGuessesRemaining = wrongGuessesRemaining - 1
            flowerImageView.image = UIImage(named: "flower\(wrongGuessesRemaining)")
        }
        
        let revealedWord = userGuessLabel.text!
        // stop game if wrongGuessesRemaining = 0
        if wrongGuessesRemaining == 0 {
            playAgainButton.isHidden = false
            guessedLetterField.isEnabled = false
            //guessLetterButton.isEnabled = false
            guessCountLabel.text = "So sorry, you are all out of guesses. Try again?"
        } else if !revealedWord.contains("_") {
            playAgainButton.isHidden = false
            guessedLetterField.isEnabled = false
            //guessLetterButton.isEnabled = false
            guessCountLabel.text = "You've got it! It took you \(guessCount) guesses to guess the word!"
            // You've Won A Game!
        
        } else {
            // Update our guess count
            let guess = ( guessCount == 1 ? "Guess" : "Guesses")
            
//             SAME AS ABOVE (ALTERNATE VERSION)
//            var guess = "guesses"
//            if guessCount == 1 {
//                guess = "guess"
//            }
            
            guessCountLabel.text = "You've Made \(guessCount) \(guess)"
        }
        
    }
    
    @IBAction func guessedLetterFieldChanged(_ sender: UITextField) {
        print("Hey! The Guessed Letter Field Changed!!")
        if let letterGuessed = guessedLetterField.text?.last {
            guessedLetterField.text = "\(letterGuessed)"
            //guessLetterButton.isEnabled = true
        } else {
            // disable the button if I don't have a single character in the guessedLetterField
            //guessLetterButton.isEnabled = false
        }
    }
    
    
    @IBAction func doneKeyPressed(_ sender: UITextField) {
        //print("In doneKeyPressed, is guessedLetterField the first responder before updateUIAfterGuess?", guessedLetterField.isFirstResponder)

        //print("In doneKeyPressed, is guessedLetterField the first responder before updateUIAfterGuess?")
        guessALetter()
        updateUIAfterGuess()
        
        //hid keyboard
        self.view.endEditing(true)
        //return false
    }
    
    
//    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
//        //print("In guessLetterButtonPressed, is guessedLetterField the first responder before updateUIAfterGuess?", guessedLetterField.isFirstResponder)
//        guessALetter()
//        updateUIAfterGuess()
//        //print("In guessLetterButtonPressed, is guessedLetterField the first responder before updateUIAfterGuess?", guessedLetterField.isFirstResponder)
//
//    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        playAgainButton.isHidden = true
        guessedLetterField.isEnabled = true
        //guessLetterButton.isEnabled = false
        flowerImageView.image = UIImage(named: "flower8")
        wrongGuessesRemaining = maxNumberOfWrongGuesses
        lettersGuessed = ""
        formatUserGuessLabel()
        guessCountLabel.text = "You've Made 0 Guesses"
        guessCount = 0
    }
}

