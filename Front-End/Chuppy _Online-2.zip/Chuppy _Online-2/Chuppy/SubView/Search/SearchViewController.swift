//
//  SearchViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 8/25/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift
import AVFoundation

@available(iOS 13.0, *)
class SearchViewController: UIViewController,UITableViewDataSource, UISearchBarDelegate, UITableViewDelegate, YourCellDelegate{
    func PlaydidPressButton(_ tag: Int) {
         //chưa có thì tạo ra
         if PlaySound.count <= 0 {
         var i = 0
           while i < self.listClass.count{
             self.PlaySound.append(0)
               i = i + 1
           }
           
             print("PS\(self.PlaySound)")
         }
        
        //Phát âm thanh
        print("\(ipRound)/upload/" +  self.mang[tag].Media)
        print(mang[tag].Media)
        let url:URL = URL(string: "\(ipRound)/upload/" + self.mang[tag].Media) ?? URL(string: "")!
         do{
             let data:Data = try Data(contentsOf: url)
             player = try AVAudioPlayer(data: data)
            player.play()
             //player.stop()
        }catch
        {
            print("Loi phat nhac")
        }
         
         //hiện hình nút
          print("I have pressed a play button (SearchView) with a tag: \(tag)")
         PlaySound[tag] = 1
          self.myTable.reloadData()
         // sau khi đã đọc xong, thì chuyển lại như cũ
         DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
             // Change `2.0` to the desired number of seconds.
            // Code you want to be delayed
             self.PlaySound[tag] = 0
             self.myTable.reloadData()
         }
    }
    
    func didPressButton(_ tag: Int) {
        print("I have pressed a button with a tag: \(tag)")
        
        //Add love list to SubRealm
        let realm = try! Realm()
        // edit
        if listClass[tag].LoveList == 0{
          try! realm.write {
             listClass[tag].LoveList = 1
         }
        } else {
            try! realm.write {
                listClass[tag].LoveList = 0
            }
        }
        //find data in SubRealm
//        print("Language: \(listClass[tag].Language)")
        
        let eventResults = realm.objects(MClass.self).filter("Language == %@", listClass[tag].Language)
        print(eventResults)
        
        //Add love list to Realm
        if eventResults[0].LoveList == 0{
          try! realm.write {
             eventResults[0].LoveList = 1
         }
        } else {
            try! realm.write {
                eventResults[0].LoveList = 0
            }
        }
        self.myTable.reloadData()

    }
    

    @IBOutlet weak var searchBar: UISearchBar!
    
    
    @IBOutlet weak var myTable: UITableView!
    
    var mang = [SubMClass]()
    var filteredData = [SubMClass]()
    var PlaySound:[Int] = []
    var WishList = [Int]()
    var LanguageData = [String]()
    var LoveList = [Int]()
    var player:AVAudioPlayer!
    var listClass = [SubMClass]()
    var ipRound = MainViewController().ipRound
    let UIUX = UIUXViewController()
    //searchBar

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)

        //DONE UI
        
        //searchBar
        self.searchBar.layer.borderWidth = 1
        self.searchBar.layer.borderColor = #colorLiteral(red: 0.6352941176, green: 0.4980392157, blue: 0.4588235294, alpha: 1)
        self.searchBar.layer.cornerRadius = 9
        searchBar.barTintColor = UIColor.init(red: 253/255, green: 250/255, blue: 247/255, alpha: 1)
        
        if let textfield = searchBar.value(forKey: "searchField") as? UITextField {

            textfield.backgroundColor = UIColor.init(red: 253/255, green: 250/255, blue: 247/255, alpha: 1)
            textfield.attributedPlaceholder = NSAttributedString(string: "Nhập từ khoá", attributes: [NSAttributedString.Key.foregroundColor : UIColor.init(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.5)])

                if let leftView = textfield.leftView as? UIImageView {
                    leftView.image = leftView.image?.withRenderingMode(.alwaysTemplate)
                    leftView.tintColor = UIColor.init(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.5)
                }

        }
        //done
        


        myTable.delegate = self
        myTable.dataSource = self
        searchBar.delegate = self
        //phải để vào view did load thì hàm search mới hoạt động
        self.addData()

        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
        updateUserInterface()
        
        //ui Search bar
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //để ko bị lỗi btn.tag
        //addData()
        //tạo cột
        return listClass.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! SearchTableViewCell
        
        //cell UI
        //cell UI
//        cell.CellUI.layer.insertSublayer(UIUX.CellGradient(width:Int(cell.CellUI.frame.size.width), heigh: Int(cell.CellUI.frame.size.height)), at: 0)
//        cell.CellUI.layer.borderWidth = 0.5
//        cell.CellUI.layer.borderColor = #colorLiteral(red: 0.6352941176, green: 0.4980392157, blue: 0.4588235294, alpha: 1)
        
        //done
        
        
        //Chọn 1 button trong cell đó
        cell.cellDelegate = self
        cell.btn.tag = indexPath.row
        //đọc
        cell.PlaycellDelegate = self
        cell.SearchPlayBtn.tag = indexPath.row
        
       DispatchQueue.main.async {

        let itemData = self.listClass[indexPath.row]
        cell.Language.text = itemData.Language
        cell.Spelling.text = itemData.Spelling
        cell.Meaning.text = itemData.Meaning
        
        if itemData.LoveList == 0 {
            //set button image
            cell.btn.setImage(UIImage(named: "AddList"), for: .normal)
         }else{
            cell.btn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
            
         }
        
        //Thay đổi hình ảnh nút âm thanh
        if self.PlaySound.count > 0 {
        if self.PlaySound[indexPath.row] == 1 {
            //phát
            cell.SearchPlayBtn.setImage(UIImage(named: "play-button-4"), for: .normal)
            
        }else {
            cell.SearchPlayBtn.setImage(UIImage(named: "SoundBig"), for: .normal)
        }
        }
        
        }
        return cell
    }


    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 94;//Choose your custom row height
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
         var searchCalc = [String?]()
        listClass = searchText.isEmpty ? filteredData : filteredData.filter({ $0.Meaning.lowercased().prefix(searchText.count) == searchText.lowercased()})
                for match in listClass{
                    searchCalc.append(match.Meaning)
                }
        //print (searchCalc)
        myTable.reloadData()

    }

    
    @IBAction func Backbtn(_ sender: Any) {
        
        if UserDefaults.standard.string(forKey: "Back") == "1"{
            quayveManhinhcuthe("ChuHan")
        }else{
            quayveManhinhcuthe("HomeView")

        }
    }
    
    func addData(){
        
        // lấy dữ liệu trong realm ra
        //nếu trong real không có dữ liệu
            self.listClass = SubMClass.getListMClass()
            //add tìm kiếm
            mang = self.listClass
            filteredData = self.listClass
        }
}
