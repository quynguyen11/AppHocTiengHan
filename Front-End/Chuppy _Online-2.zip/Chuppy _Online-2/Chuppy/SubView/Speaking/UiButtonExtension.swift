//
//  UiButtonExtension.swift
//  AppLuanVan
//
//  Created by Apple on 8/30/20.
//  Copyright © 2020 Nguyen Ngoc Quy. All rights reserved.
//

import Foundation
import UIKit

extension UIButton{
    
    func shake(){
        
        let shake = CABasicAnimation(keyPath: "position")
        shake.duration = 1
     // shake.repeatCount = 1
     // shake.autoreverses = true

       // let fromPoint = CGPoint(x: center.x - 5, y: center.y)
     //   let formValue = NSValue(cgPoint: fromPoint)

        let toPoint = CGPoint(x: center.x, y: center.y - 60)
        let toValue = NSValue(cgPoint: toPoint )

      // shake.fromValue = formValue
       shake.toValue = toValue
    
        layer.add(shake, forKey: nil)
        
        

        
        
    }
    
       func pulse(){
        
        
        let pulse = CABasicAnimation(keyPath: "transform.scale")
        pulse.duration = 1
        pulse.fromValue = 0.95
        pulse.toValue = 1.25
        pulse.autoreverses = true
        pulse.repeatCount = 3
        
        layer.add(pulse, forKey: nil)
    }
    
    func unshake(){
         
         let unshake = CABasicAnimation(keyPath: "position")
         unshake.duration = 1
      // shake.repeatCount = 1
      // shake.autoreverses = true
        
        // let fromPoint = CGPoint(x: center.x - 5, y: center.y)
      //   let formValue = NSValue(cgPoint: fromPoint)

         let toPoint = CGPoint(x: center.x, y: center.y + 60)
         let toValue = NSValue(cgPoint: toPoint )

       // shake.fromValue = formValue
        unshake.toValue = toValue
     
         layer.add(unshake, forKey: nil)
        
        let pulse = CABasicAnimation(keyPath: "transform.scale")
        pulse.duration = 1
        pulse.fromValue = 1
        pulse.toValue = 0.75
        
        
        layer.add(pulse, forKey: nil)
    }
         
}
