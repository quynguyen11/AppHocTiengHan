//
//  TestSpeakingViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 9/29/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import AVFoundation
import Speech
import AVKit
import RealmSwift

@available(iOS 13.0, *)
class TestSpeakingViewController: UIViewController {
    
    @IBOutlet weak var lblText: UILabel!
    var addLoveList = 0
    let speechRecognizer        = SFSpeechRecognizer(locale: Locale(identifier: "ko_KR"))
    //ko_KR, en_US, vi_VN

    var recognitionRequest      : SFSpeechAudioBufferRecognitionRequest?
    var recognitionTask         : SFSpeechRecognitionTask?
    let audioEngine             = AVAudioEngine()

    var player:AVAudioPlayer!
    var sound: String = ""
    let realm = try! Realm()
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? ""
    var value: String = ""
    var counts: Int = 0
    var random: Int = 0
    var arrSave:[String] = []
    var arrCount = 0
    let UIUX = UIUXViewController()
    @IBOutlet weak var LoveBtn: UIButton!
    @IBOutlet weak var ChuHanlbl: UILabel!
    @IBOutlet weak var PhienAmlbl: UILabel!
    @IBOutlet weak var DichNghialbl: UILabel!
    @IBOutlet weak var LikeOrUnlike: UIImageView!
    
    //start recording
    @IBOutlet weak var record1: UIButton!
    
    //stop recording
    @IBOutlet weak var record2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
       
        self.view.applyGradient(colours: [UIUX.part1, UIUX.part2], locations: [UIUX.loc1,UIUX.loc2])

        //DONE UI
        
        LikeOrUnlike.isHidden = true
        
        if UserDefaults.standard.string(forKey: "Test") != ""{
            value = UserDefaults.standard.string(forKey: "Test") ?? ""
            
        }else{
            counts = SubMClass.getListMClass().count
            
             random = Int.random(in: 0..<counts)
            value = SubMClass.getListMClass()[random].Language
            
        }
        
        //Add data
        AddData()
        //save data for previousBtn
        arrSave.append(ChuHanlbl.text ?? "")
        arrCount = arrSave.count
        
        //setup speech
        self.setupSpeech()
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
    }

    
    func AddData(){
        
        let eventResults = realm.objects(SubMClass.self).filter("Language == %@", value )
        
        print("TEST LANGUAGE: ",eventResults[0].Language)
        
        ChuHanlbl.text = eventResults[0].Language
        PhienAmlbl.text = eventResults[0].Spelling
        DichNghialbl.text = eventResults[0].Meaning
        sound = eventResults[0].Media
        
        
        
        //setup UI for lovelist
        if eventResults[0].LoveList == 0{
            LoveBtn.setImage(UIImage(named: "AddList2"), for: .normal)
        } else {
            LoveBtn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
        }
        

    }
    
    @IBAction func NextBtn(_ sender: Any) {
        counts = SubMClass.getListMClass().count
         random = Int.random(in: 0..<counts)
        value = SubMClass.getListMClass()[random].Language
        
        AddData()
        
        //save data for previousBtn
        arrSave.append(ChuHanlbl.text ?? "")
        arrCount = arrSave.count
        //
    }
    
    @IBAction func previousBtn(_ sender: Any) {
        
        if arrCount > 2{
           value = arrSave[arrCount - 1]
            arrCount = arrCount - 1
        }else{
            value = arrSave[0]
        }
        AddData()
    }
    @IBAction func shakeButtonTapped(_ sender: UIButton) {
        
        //bắt đầu ghi âm
        
        self.startRecording()
        LikeOrUnlike.isHidden = true
        print("Start-Recording")
        
        sender.shake()
    
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { (abc) in
            
            self.record1.isHidden = true
            self.record2.isHidden = false
            self.record2.pulse()
        }
       
    }
    
    @IBAction func recording(_ sender: UIButton) {
        
            //stop recording
        print("Stop-Recording")
        
        //so sánh chữ khi nói với kết quả
        LikeOrUnlike.isHidden = false
        if ChuHanlbl.text == lblText.text{
            LikeOrUnlike.image = UIImage(named: "like")
        
        }else if ChuHanlbl.text != lblText.text{
            LikeOrUnlike.image = UIImage(named: "unlike")
        }
        print(ChuHanlbl.text)
        
        
        
        self.audioEngine.stop()
        self.recognitionRequest?.endAudio()
        lblText.text = "---"
        
        
        
        sender.unshake()
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { (abc) in
                  
                  self.record1.isHidden = false
                  self.record2.isHidden = true
              
              }


    }
    
    @IBAction func btn_playmedia(_ sender: Any) {
        
        print("IP Play Music: " + ipRound)
        print( "IP Play Music: "+"\(ipRound)/upload/" + sound)
        
        let url:URL = URL(string: "\(ipRound)/upload/" + sound)!
         do{
             let data:Data = try Data(contentsOf: url)
             player = try AVAudioPlayer(data: data)
            player.play()
             //player.stop()
        }catch
        {
            print("Loi phat nhac")
        }//
        
    }
    
    @IBAction func AddLoveList(_ sender: Any) {
        if addLoveList == 0 {
            //set button image
            LoveBtn.setImage(UIImage(named: "AddList2"), for: .normal)
            addLoveList = 1
         }else{
            LoveBtn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
            addLoveList = 0
            
         }
        //add list to database
        let eventResults = realm.objects(SubMClass.self).filter("Language == %@", ChuHanlbl.text as Any )
        print(eventResults)
        
        //Add love list to Realm
        if eventResults[0].LoveList == 0{
          try! realm.write {
             eventResults[0].LoveList = 1
         }
        } else {
            try! realm.write {
                eventResults[0].LoveList = 0
            }
        }
    }
    
    @IBAction func BackBtn(_ sender: Any) {
        if player != nil{
            try player.stop()
        }
        print("ViewBack: \(UserDefaults.standard.string(forKey: "Back"))")
        if UserDefaults.standard.string(forKey: "Back") == "1"{
            quayveManhinhcuthe("ChuHan")
        }else{
            quayveManhinhcuthe("HomeView")

        }
    }
    
    func setupSpeech() {

//        self.btnStart.isEnabled = false
        self.speechRecognizer?.delegate = self

        SFSpeechRecognizer.requestAuthorization { (authStatus) in

            var isButtonEnabled = false

            switch authStatus {
            case .authorized:
                isButtonEnabled = true

            case .denied:
                isButtonEnabled = false
                print("User denied access to speech recognition")

            case .restricted:
                isButtonEnabled = false
                print("Speech recognition restricted on this device")

            case .notDetermined:
                isButtonEnabled = false
                print("Speech recognition not yet authorized")
            }

            OperationQueue.main.addOperation() {
                self.record1.isEnabled = isButtonEnabled
            }
        }
    }
    
    func startRecording() {

        // Clear all previous session data and cancel task
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }

        // Create instance of audio session to record voice
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSession.Category.record, mode: AVAudioSession.Mode.measurement, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }

        self.recognitionRequest = SFSpeechAudioBufferRecognitionRequest()

        let inputNode = audioEngine.inputNode

        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }

        recognitionRequest.shouldReportPartialResults = true

        self.recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in

            var isFinal = false

            if result != nil {

                self.lblText.text = result?.bestTranscription.formattedString
                isFinal = (result?.isFinal)!
                
                //check
            }

            if error != nil || isFinal {

                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)

                self.recognitionRequest = nil
                self.recognitionTask = nil

                //btnStart
                self.record1.isEnabled = true
            }
        })

        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }

        self.audioEngine.prepare()

        do {
            try self.audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }

        self.lblText.text = " "
    }

}

@available(iOS 13.0, *)
extension TestSpeakingViewController: SFSpeechRecognizerDelegate {

    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
    }
}
