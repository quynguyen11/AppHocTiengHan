//
//  Model_MongoDB.swift
//  Korean Language
//
//  Created by QuangTran on 12/5/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation

////////////////////////////////////Get data from internet
struct GramListWord:Decodable{
    var kq:Int
    var arrGrammar:[VocaWord]
    
    
}

struct VocaListWord:Decodable{
    var kq:Int
    var arrLession:[VocaWord]
    
    
}

struct VocaWord:Decodable{
    
    
    
    var _id:String
    var Title: String
    var File: String
    
    init(id:String, Title:String, File:String) {
        self._id = id
        self.Title = Title
        self.File = File

       
    }

    
}

////////////////////Model for Video Lyric
struct SubVideoListWord:Decodable{
    var kq:Int
    var DSVideo:[SubVideoWord]

}

struct SubVideoWord:Decodable{
    

    var _id:String
    var Title: String
    var File: String
    var DSLyric: [SubVideoLyric]

    init(id:String, Title:String, File:String, DSLyric:[SubVideoLyric]) {
        self._id = id
        self.Title = Title
        self.File = File
        self.DSLyric = DSLyric
    }

}

struct SubVideoLyric:Decodable{

    var _id:String
    var Korean: String
    var English: String
    var Time: String
}
