//
//  VocabularyViewController.swift
//  Korean Language
//
//  Created by QuangTran on 10/31/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift
import Photos

@available(iOS 13.0, *)
@available(iOS 13.0, *)
@available(iOS 13.0, *)
@available(iOS 13.0, *)
class VocabularyViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, VocabularyCellDelegate, URLSessionDelegate, URLSessionDataDelegate {

    var timer : Timer?
    var number = 1
    var getFileName: [String] = []
    var mang:[VocaWord]  = []
    var mangVideo:[SubVideoWord]  = []
    var ipRound: String = ""
    var request = URLRequest(url: URL(string: "http://123.com/lessionKorea")!)
    let UIUX = UIUXViewController()
    var count = 0
    var arrTitle: [Int] = []
    //Show download speed
    typealias speedTestCompletionHandler = (_ megabytesPerSecond: Double? , _ error: Error?) -> Void
    var speedTestCompletionBlock : speedTestCompletionHandler?
    var startTime: CFAbsoluteTime!
    var stopTime: CFAbsoluteTime!
    var bytesReceived: Int!
    var urlString:String?
    //
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var BackbTN: UIButton!
    @IBOutlet weak var Loader: UIActivityIndicatorView!
    @IBOutlet weak var CoverView: UIView!
    @IBOutlet weak var TitleLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showLoader(true)
        //self.showLoader(false)
        if UserDefaults.standard.string(forKey: "VocaOrGram") == "VIDEO"{
            LoadVideoData()
        }else{
            loadData()
        }

            //SET UI
            
        self.view.layer.insertSublayer(UIUX.Gradient(width:Int(self.view.frame.size.width), heigh: Int(self.view.frame.size.height)), at: 0)
            self.myTable.backgroundColor = UIUXViewController().UIBackGround
            //DONE UI
        
            myTable.delegate = self
            myTable.dataSource = self

            print("MANG: \(self.mang.count)")
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)
        
        //load label
       if UserDefaults.standard.string(forKey: "VocaOrGram") == "VIDEO"{
        TitleLBL.text = "Video"
       }
       else if UserDefaults.standard.string(forKey: "VocaOrGram") == "voca"  {
        TitleLBL.text = "Vocabulary"
       } else {
        TitleLBL.text = "Grammarly"
       }
        
    }

    func showLoader(_ show: Bool) {
        DispatchQueue.main.async {
            if show {
                self.Loader.isHidden = false
                self.CoverView.isHidden = false
                self.Loader.startAnimating()
            } else {
                self.Loader.stopAnimating()
                self.Loader.isHidden = true
                self.CoverView.isHidden = true
            }
        }
    }
    
    @IBAction func Back(_ sender: Any) {
        quayveManhinhcuthe("HomeView")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if UserDefaults.standard.string(forKey: "VocaOrGram") == "VIDEO"{
            return mangVideo.count
        }
        return mang.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        showLoader(false)
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! VocabularyTableViewCell
        
        if UserDefaults.standard.string(forKey: "VocaOrGram") == "VIDEO"{
            cell.TitleLbl.text = self.mangVideo[indexPath.row].Title
            
            //set download button
            if checkExistVideo(VideoName: mangVideo[indexPath.row].Title) == true{
                cell.DownloadVideoLbl.isHidden = true
                cell.ReadLbl.isHidden = false
            }else{
                cell.ReadLbl.isHidden = true
            }
        }
        else{
            cell.TitleLbl.text = self.mang[indexPath.row].Title
            
        }
        
        //chon 1 button
        cell.VocabularyYourCellDelegate = self
        cell.ReadLbl.tag = indexPath.row
        //download button
        cell.DownloadBTn = self
        cell.DownloadVideoLbl.tag = indexPath.row
        
        //tạo hình ảnh trên cell
        cell.sttLbl.image = UIUXViewController().UIUXButton()
        
        //bo góc
        let
            width = cell.sttLbl.frame.size.width
        cell.sttLbl.layer.cornerRadius = width / 2.2
        
        //tạo số trong hình
        let s2 = NSAttributedString(string: "\(arrTitle[indexPath.row])" , attributes:
                    [.font:UIFont(name: "Georgia", size: 90)!,
                     .foregroundColor: UIColor.brown])
        
        let sz = cell.sttLbl.image?.size
        let r = UIGraphicsImageRenderer(size:sz!)
        cell.sttLbl.image = r.image {
                    _ in
            cell.sttLbl.image!.draw(at:.zero)
            s2.draw(at: CGPoint(x:width, y:width/4))
                }
        

                return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 128;//Choose your custom row height
    }
    
    //button play video / read pdf
    func pressReadPdfBtn(_ tag: Int) {
        //print("Press: \(tag)")
        //print("FileName: \(mang[tag].File)")
        if UserDefaults.standard.string(forKey: "VocaOrGram") == "VIDEO"{
            UserDefaults.standard.set(mangVideo[tag].File, forKey: "SubVideoURL") //Save to userdefault
            UserDefaults.standard.set(tag as Int, forKey: "tag")
            UserDefaults.standard.set(mangVideo[tag].Title, forKey: "VideoTitle")
            quayveManhinhcuthe("VideoLearnKorea")
        }else{
            UserDefaults.standard.set(mang[tag].File, forKey: "KeyPdfRead") //Save to userdefault
            
           // addData()
            
            quayveManhinhcuthe("LearnVocabulary")
        }
    }
    
    func DownloadVideoURL(_ tag: Int) {
        
        self.Loader.isHidden = false
        self.CoverView.isHidden = false
        self.Loader.startAnimating()
    
        let DocumentDirectory = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        let DirPath = DocumentDirectory.appendingPathComponent("VideoFile")
        do
        {
            try FileManager.default.createDirectory(atPath: DirPath!.path, withIntermediateDirectories: true, attributes: nil)

            showLoader(false)

        }
        catch let error as NSError
        {
            print("Unable to create directory \(error.debugDescription)")
            showLoader(false)
        }
        print("Dir Path = \(DirPath!)")
        
        /// end check folder ///
        
        //check if file exist
        if checkExistVideo(VideoName: mangVideo[tag].Title) == false{
            
            
        let videoUrl = UserDefaults.standard.string(forKey: "Key")! + "/upload/" + mangVideo[tag].File
            urlString = videoUrl
        let VideoFileName = mangVideo[tag].Title
        print("SubVideoURL: \(videoUrl)")
            //Show download speed
            testSpeed()
            
        DispatchQueue.main.async {
            if let url = URL(string: videoUrl),
                let urlData = NSData(contentsOf: url) {
                let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0];
                let filePath="\(documentsPath)/VideoFile/\(VideoFileName).mp4"
                DispatchQueue.main.async {
                    
                    urlData.write(toFile: filePath, atomically: true)
                    //print("Video is saved!")
                    PHPhotoLibrary.shared().performChanges({
                        PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: URL(fileURLWithPath: filePath))
                    }) { completed, error in
                        if completed {
                            print("Video is saved!")
                            self.showLoader(false)

                        }
                    }
                    //RELOAD DATA
                    self.myTable.reloadData()
                    
                }
                
            }
            
        }
        
        }else{
            print("This video is already have")
        }
        
    }
    func checkExistVideo(VideoName: String)->Bool{
        //get data from file manager
        let documentDirectoryPath:String = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
            let myFilesPath = "\(documentDirectoryPath)/VideoFile"
            let filemanager = FileManager.default
            let files = filemanager.enumerator(atPath: myFilesPath)
            while let file = files?.nextObject() {
                let filterNormal = "\(file)".components(separatedBy: ".")
                //print(filterNormal[0])
                getFileName.append(filterNormal[0])
            }
        let filteredStrings : [String] = getFileName.filter({
                return $0.contains(VideoName)
            })
        //print("FILE NAME FILE NAME: \(filteredStrings)")
        if filteredStrings.count > 0{
            return true
        }
        
        return false
    }
    

    ///PDF File
    func loadData(){

        ///Kết thúc : hàm lấy ip address
        ipRound = UserDefaults.standard.string(forKey: "Key") ?? ""

        if UserDefaults.standard.string(forKey: "VocaOrGram") == "voca"{
            request = URLRequest(url: URL(string: "\(ipRound)/lessionKorea")!)
        }else{
            //vocabulary
            request = URLRequest(url: URL(string: "\(ipRound)/grammarKorea")!)
        }
        print("URL: \(request)")
            
                     request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request){ [self] data, response, error in

        guard let data = data, error == nil else {
                    return
        }
        let jsonDecoder = JSONDecoder()
            
        //print("DATAVOC: \(data)")
        if UserDefaults.standard.string(forKey: "VocaOrGram") == "voca"{
            let listWord = try? jsonDecoder.decode(VocaListWord.self,from:data)

            self.mang = listWord!.arrLession
        }else{
            let listWord = try? jsonDecoder.decode(GramListWord.self,from:data)

            self.mang = listWord!.arrGrammar
        }
        DispatchQueue.main.async {
            for i in 0..<self.mang.count{
                arrTitle.append(i + 1)
            }
            self.myTable.reloadData()
        }

    }
        task.resume()
   
}
    
    /////Video Korea

    func LoadVideoData(){
        
        ipRound = UserDefaults.standard.string(forKey: "Key") ?? ""
 
        var request = URLRequest(url: URL(string: "\(ipRound)/videoKorean")!)
        print("URL: \(request)")

                     request.httpMethod = "GET"
                     let task = URLSession.shared.dataTask(with: request){ data, response, error in

                     guard let data = data,
                           error == nil else {
                                 return
                         }
                         let jsonDecoder = JSONDecoder()
                        //print("DATA Sub Video: \(data)")
                        let listWord = try? jsonDecoder.decode(SubVideoListWord.self,from:data)
                        
                        
                        self.mangVideo = listWord!.DSVideo
                        
                        DispatchQueue.main.async {
                            for i in 0..<self.mangVideo.count{
                                self.arrTitle.append(i + 1)
                            }
                            self.myTable.reloadData()
                        }

                 }
                    task.resume()
    }
    
    /////Show download speed and file complete
    func testSpeed()  {


        let url = URL(string: urlString ?? "")
           let request = URLRequest(url: url!)

        let session = URLSession.shared

        let startTime = Date()

        let task =  session.dataTask(with: request) { (data, resp, error) in

            guard error == nil && data != nil else{

                print("connection error or data is nill")

                return
            }

            guard resp != nil else{

                print("respons is nill")
                return
            }


                let length  = CGFloat( (resp?.expectedContentLength)!) / 1000000.0

                print(length)



            let elapsed = CGFloat( Date().timeIntervalSince(startTime))

            print("elapsed: \(elapsed)")

            print("Speed: \(length/elapsed) Mb/sec")


        }


        task.resume()


    }
    ///// Done download speed
}
