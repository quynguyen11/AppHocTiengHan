//
//  VocabularyTableViewCell.swift
//  Korean Language
//
//  Created by QuangTran on 10/31/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit

protocol VocabularyCellDelegate : class {
    func pressReadPdfBtn(_ tag: Int)
    func DownloadVideoURL(_ tag: Int)
}

class VocabularyTableViewCell: UITableViewCell {
    
    var VocabularyYourCellDelegate: VocabularyCellDelegate?
    var DownloadBTn: VocabularyCellDelegate?

    @IBOutlet weak var sttLbl: UIImageView!
    @IBOutlet weak var ReadLbl: UIButton!
    @IBOutlet weak var TitleLbl: UILabel!
    @IBOutlet weak var CellOutLet: UIView!
    @IBOutlet weak var DownloadVideoLbl: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.CellOutLet.backgroundColor = UIUXViewController().UIBackGround
        // Initialization code
        if UserDefaults.standard.string(forKey: "VocaOrGram") == "VIDEO"{
            DownloadVideoLbl.isHidden = false
        }else{
            DownloadVideoLbl.isHidden = true
        }
    }

    
    @IBAction func ReadBtn(_ sender: UIButton) {
        VocabularyYourCellDelegate?.pressReadPdfBtn(sender.tag)
        
    }
    
    @IBAction func DownloadVideo(_ sender: UIButton) {
        DownloadBTn?.DownloadVideoURL(sender.tag)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
