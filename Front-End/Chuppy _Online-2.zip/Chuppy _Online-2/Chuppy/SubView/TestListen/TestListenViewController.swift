//
//  TestListenViewController.swift
//  Korean Language
//
//  Created by Quang Tran on 9/24/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import UIKit
import RealmSwift
import AVFoundation

@available(iOS 13.0, *)
class TestListenViewController: UIViewController {
    
    var timer : Timer?
    var counterStop = 8
    var addLoveList = 0
    let realm = try! Realm()
    let ipRound: String = UserDefaults.standard.string(forKey: "Key") ?? ""
    //data
    var Scores: Int = 0
    var Percents: Int = 0
    var CountWrong: Int = 0
    var Answers: String = ""
    //Dữ liệu vào
    var Questions: [String] = []
    var InlineQuestions: [String] = []
    var CorrectBtn: UIButton!
    var countss: Int = 0
    var sound: String = ""
    var player:AVAudioPlayer!
    var ModelTest = Test()
    var mang = [SubMClass]()
    let UIUX = UIUXViewController()
    var Aws3lbl: UIButton? = nil
    var Aws2lbl: UIButton? = nil
    var Aws1lbl: UIButton? = nil
    @IBOutlet weak var Timelbl: UILabel!
    
    @IBOutlet weak var LoveBtn: UIButton!
    @IBOutlet weak var View2: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //SET UI
     
        self.view.applyGradient(colours: [UIUX.part1, UIUX.part2], locations: [UIUX.loc1,UIUX.loc2])
        
        //button UI
        ButtonInView()


        //DONE UI

        // Do any additional setup after loading the view.
        
        NotificationCenter.default.post(name: NSNotification.Name("viewLoaded"), object: nil)
        
        ModelTest.addData()
        
        for match in ModelTest.mang{
            Questions.append(match.Language)
        }
        GenerateQuestion()
        
        //cảnh báo mất kết nối mạng
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(statusManager),
                         name: .flagsChanged,
                         object: nil)

    }
    
    func ButtonInView(){
        
        Aws3lbl = UIButton(frame: CGRect(x: self.view.frame.size.width/5.35, y: self.view.frame.size.height/1.32377, width: self.view.frame.size.width/1.595, height: 40))
        Aws3lbl?.layer.cornerRadius = 5
        Aws3lbl?.layer.borderWidth = 1
        Aws3lbl?.layer.borderColor = UIColor.init(red: 138/255, green: 138/255, blue: 138/255, alpha: 1).cgColor
        Aws3lbl?.setTitle("(Đáp án)", for: .normal)
        Aws3lbl?.titleLabel?.font =  UIFont(name: "SF Pro Text", size: 18)
        Aws3lbl?.setTitleColor(UIColor.init(red: 138/255, green: 138/255, blue: 138/255, alpha: 1), for: .normal)
        Aws3lbl?.addTarget(self, action: #selector(Aws3), for: .touchUpInside)

        self.view.addSubview(Aws3lbl!)
        
        Aws2lbl = UIButton(frame: CGRect(x: self.view.frame.size.width/5.35, y: self.view.frame.size.height/1.32377 - 56, width: self.view.frame.size.width/1.595, height: 40))
        Aws2lbl?.layer.cornerRadius = 5
        Aws2lbl?.layer.borderWidth = 1
        Aws2lbl?.layer.borderColor = UIColor.init(red: 138/255, green: 138/255, blue: 138/255, alpha: 1).cgColor
        Aws2lbl?.setTitle("(Đáp án)", for: .normal)
        Aws2lbl?.titleLabel?.font =  UIFont(name: "SF Pro Text", size: 18)
        Aws2lbl?.setTitleColor(UIColor.init(red: 138/255, green: 138/255, blue: 138/255, alpha: 1), for: .normal)
        Aws2lbl?.addTarget(self, action: #selector(Aws2), for: .touchUpInside)

        self.view.addSubview(Aws2lbl!)
        
        Aws1lbl = UIButton(frame: CGRect(x: self.view.frame.size.width/5.35, y: self.view.frame.size.height/1.32377 - 56*2, width: self.view.frame.size.width/1.595, height: 40))
        Aws1lbl?.layer.cornerRadius = 5
        Aws1lbl?.layer.borderWidth = 1
        Aws1lbl?.layer.borderColor = UIColor.init(red: 138/255, green: 138/255, blue: 138/255, alpha: 1).cgColor
        Aws1lbl?.setTitle("(Đáp án)", for: .normal)
        Aws1lbl?.titleLabel?.font =  UIFont(name: "SF Pro Text", size: 18)
        Aws1lbl?.setTitleColor(UIColor.init(red: 138/255, green: 138/255, blue: 138/255, alpha: 1), for: .normal)
        Aws1lbl?.addTarget(self, action: #selector(Aws1), for: .touchUpInside)

        self.view.addSubview(Aws1lbl!)
    }

    @IBAction func BackBtn(_ sender: Any) {
        do{
            if player != nil{
                try player.stop()
            }
        }catch{
            print("Audio is already stop")
        }
        timer?.invalidate()
        timer = nil
        
        if UserDefaults.standard.string(forKey: "Back") == "1"{
            quayveManhinhcuthe("ChuHan")
        }else{
            quayveManhinhcuthe("HomeView")

        }
    }
    
    
    @IBAction func AddLoveListBtn(_ sender: Any) {
        
        if addLoveList == 0 {
            //set button image
            LoveBtn.setImage(UIImage(named: "AddList2"), for: .normal)
            addLoveList = 1
         }else{
            LoveBtn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
            addLoveList = 0
            
         }
        //add list to database
        let eventResults = realm.objects(SubMClass.self).filter("Language == %@", Answers )
        print(eventResults)
        
        //Add love list to Realm
        if eventResults[0].LoveList == 0{
          try! realm.write {
             eventResults[0].LoveList = 1
         }
        } else {
            try! realm.write {
                eventResults[0].LoveList = 0
            }
        }
        
    }
    
    @IBAction func PlayBtn(_ sender: Any) {
 
                print("IP Play Music: " + ipRound)
                print( "IP Play Music: "+"\(ipRound)/upload/" + sound)
                
                let url:URL = URL(string: "\(ipRound)/upload/" + sound)!
                 do{
                     let data:Data = try Data(contentsOf: url)
                     player = try AVAudioPlayer(data: data)
                    player.play()
                     //player.stop()
                }catch
                {
                    print("Loi phat nhac")
                }
    }

    @IBAction func Aws1(_ sender: Any) {
        Check(txt: Aws1lbl?.titleLabel?.text ?? "", WrongBtn: Aws1lbl!)
    }
    @IBAction func Aws2(_ sender: Any) {
        Check(txt: Aws2lbl?.titleLabel?.text ?? "", WrongBtn: Aws2lbl!)
    }
    @IBAction func Aws3(_ sender: Any) {
        Check(txt: Aws3lbl?.titleLabel?.text ?? "", WrongBtn: Aws3lbl!)
    }
    
    @objc func CountStop() {
        if counterStop > 0 {
            counterStop = counterStop - 1
            Timelbl.text = String(counterStop)
        }
        //Show answer when time to 1 second
        if counterStop == 1{
            CorrectBtn.backgroundColor = UIColor(red: 255/255, green: 158/255, blue: 159/255, alpha: 1)
        }
        if counterStop <= 0 {
            //TimeIntervals -= 1
            GenerateQuestion()
        }
    }
    
    func Check(txt: String, WrongBtn: UIButton){
        
        //txt là chữ đúng
        if txt == Answers{
            //TimeIntervals -= 1
            CorrectBtn.backgroundColor = UIColor.gray
            //score (Cộng điểm)
            Scores = Scores + 1
            //Default Button
            WrongBtn.backgroundColor = nil
            CountWrong = 0
            
            //tạo ra bộ câu hỏi mới
            Aws1lbl?.titleLabel?.text = nil
            Aws2lbl?.titleLabel?.text = nil
            Aws3lbl?.titleLabel?.text = nil
            InlineQuestions.removeAll()
            //nếu đã đủ 10 câu
            GenerateQuestion()
            
        }
        //wrong choose
        else {
            WrongBtn.backgroundColor = UIColor(red: 162/255, green: 127/255, blue: 117/255, alpha: 1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                // Change `2.0` to the desired number of seconds.
               // Code you want to be delayed
                WrongBtn.backgroundColor = nil
            }
            CorrectBtn.backgroundColor = nil

            //nếu đánh sai 5 lần 
            CountWrong = CountWrong + 1
            if CountWrong >= 5 {
                CorrectBtn.backgroundColor = UIColor(red: 255/255, green: 158/255, blue: 159/255, alpha: 1)
            }

        }
        
    }
    
    func GenerateQuestion(){
        
        //player
        if player != nil{
            try player.stop()
        }
        
        //stop time. Must check or wil be increase time
        if timer != nil{
            timer?.invalidate()
            timer = nil
        }
        //set default time
        Timelbl.text = "8"
        counterStop = 8

        //timer
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(CountStop), userInfo: nil, repeats: true)

        
        //tạo mảng nhỏ đưa 4 đáp án bất kỳ (luôn có 1 đáp án đúng)
        var i = 0
        while i < 3 {
            
            //Khởi tạo câu hỏi
            let count = Questions.count
            
            let random: String = Questions[Int.random(in: 0..<count)]
            //xét nếu trùng đáp án thì ko cho đưa vào
            var flag = 0
            for n in 0..<InlineQuestions.count{
                
                if InlineQuestions[n] == random {
                    
                    flag = 1
                }
            }
            if flag == 0 {
                InlineQuestions.append(random)
                 i = i + 1
            }
            
        }
        
        //Khởi tạo câu trả lời
        Answers = InlineQuestions[Int.random(in: 0..<InlineQuestions.count)]
        print("Anws: ", Answers)
        
        
        //add câu đúng vào trước
//        InlineQuestions.append(Answers)
        //add tìm kiếm
        
        let info = realm.objects(SubMClass.self).filter("Language = %@", Answers)
        
        print("Sound: \(info.first?.Media ?? "")")
        sound = "\(info.first?.Media ?? "")"
        
        
        print(InlineQuestions)
        
        //đưa mảng nhỏ đó vào button
        //Tạo cho

        Aws1lbl?.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
        //xoá đi phần tử vừa tạo
        RemoveElement(itemToRemoves: Aws1lbl?.titleLabel?.text ?? "")
        
        
        Aws2lbl?.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
        RemoveElement(itemToRemoves: Aws2lbl?.titleLabel?.text ?? "")
        
        Aws3lbl?.setTitle(InlineQuestions[Int.random(in: 0..<InlineQuestions.count)], for: .normal)
        RemoveElement(itemToRemoves: Aws3lbl?.titleLabel?.text ?? "")

        //đưa button đúng vào
        if Aws1lbl?.titleLabel?.text == Answers{
            CorrectBtn = Aws1lbl
        }else if Aws2lbl?.titleLabel?.text == Answers{
            CorrectBtn = Aws2lbl
        }else if Aws3lbl?.titleLabel?.text == Answers{
            CorrectBtn = Aws3lbl
        }
        //get default color button
        CorrectBtn.backgroundColor = nil
        
        if info.first?.LoveList == 0 {
            //set button image
            LoveBtn.setImage(UIImage(named: "AddList2"), for: .normal)
            addLoveList = 1
         }else{
            LoveBtn.setImage(UIImage(named: "AddList_Yellow"), for: .normal)
            addLoveList = 0
            
         }
        
    }
    
    func RemoveElement(itemToRemoves:String){
        let itemToRemove = itemToRemoves

        while InlineQuestions.contains(itemToRemove) {
            if let itemToRemoveIndex = InlineQuestions.firstIndex(of: itemToRemove) {
                InlineQuestions.remove(at: itemToRemoveIndex)
            }
        }

        
    }

    
}
