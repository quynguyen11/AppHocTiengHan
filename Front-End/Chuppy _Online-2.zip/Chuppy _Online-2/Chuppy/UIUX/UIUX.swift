//
//  UIUX.swift
//  Korean Language
//
//  Created by QuangTran on 11/15/20.
//  Copyright © 2020 Quang Tran. All rights reserved.
//

import Foundation
import UIKit


class UIUXViewController{
    //HomeViewController
    let UIBackGround = UIColor(red:253/255, green:250/255, blue:247/255, alpha: 1)
    let UIBackGroundWriting = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1)
    let part1: UIColor = UIColor.init(red: 250/255, green: 164/255, blue: 199/255, alpha: 1)
    let part11: UIColor = UIColor.init(red: 251/255, green: 205/255, blue: 218/255, alpha: 1)
    let part2: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    
    let part12: UIColor = UIColor.init(red: 162/255, green: 127/255, blue: 117/255, alpha: 1)
    let part13: UIColor = UIColor.init(red: 255/255, green: 158/255, blue: 159/255, alpha: 1)
    
    let part14: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    let part15: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    
    let part16: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    let part17: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    
    let part18: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    let part19: UIColor = UIColor.init(red: 255/255, green: 240/255, blue: 219/255, alpha: 1)
    
    let loc1: NSNumber = 0.0
    let loc2: NSNumber = 1.0
    
    
    func UIUXButton() -> UIImage{
        let Image: UIImage = UIImage.gradientImageWithBounds(bounds: CGRect(x: 0, y: 0, width: 200, height: 200), colors: [part1.cgColor, part2.cgColor])

        return Image

    }
    //view.frame.size.width
    func Gradient(width: Int, heigh: Int)->CALayer{
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.colors = [part1.cgColor, part2.cgColor]
            gradient.locations = [0.0 , 1.0]
        gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradient.frame = CGRect(x: Int(0.0), y: Int(1.0), width: width, height: heigh)
        
       return gradient
        

    }
    func CellGradient(width: Int, heigh: Int)->CALayer{
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.colors = [part11.cgColor, part2.cgColor]
            gradient.locations = [0.0 , 1.0]
        gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradient.frame = CGRect(x: Int(0.0), y: Int(1.0), width: width, height: heigh)
        
       return gradient
        

    }
    
    
}
extension UIImage {
    static func gradientImageWithBounds(bounds: CGRect, colors: [CGColor]) -> UIImage {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = colors
        
        UIGraphicsBeginImageContext(gradientLayer.bounds.size)
        gradientLayer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}

extension UIView {
    @discardableResult
    func applyGradient(colours: [UIColor]) -> CAGradientLayer {
        return self.applyGradient(colours: colours, locations: nil)
    }

    @discardableResult
    func applyGradient(colours: [UIColor], locations: [NSNumber]?) -> CAGradientLayer {
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.frame = self.bounds
        gradient.colors = colours.map { $0.cgColor }
        gradient.locations = locations
        self.layer.insertSublayer(gradient, at: 0)
        return gradient
    }
}

